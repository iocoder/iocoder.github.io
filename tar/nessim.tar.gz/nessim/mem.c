#include <stdio.h>
#include <stdlib.h>

#include "mem.h"
#include "cartridge.h"
#include "joypad.h"

/* CPU RAM: */
unsigned char internal_ram[2048];

/* PPU external RAM: */
unsigned char namtab1[0x400];
unsigned char namtab2[0x400];

unsigned char cpu_mem_read(unsigned short addr) {

    unsigned char ret = 0;
    if (addr < 0x2000) {
        ret = internal_ram[addr & 0x7FF];
    } else if (addr < 0x2008) {
        /* ppu registers */
        ret = ppu_reg_read(addr & 7);
    } else if (addr >= 0x4000 && addr < 0x4017) {
        /* misc registers */
        if (addr < 0x4014) {
            /* audio */
            ret = apu_reg_read(addr & 0x1F);
        } else if (addr == 0x4014) {
            /* DMA */
        } else if (addr == 0x4015) {
            /* audio */
            ret = apu_reg_read(addr & 0x1F);
        } else if (addr == 0x4016) {
            /* controller 0 read */
            ret = joypad0_read();
        } else if (addr == 0x4017) {
            /* controller 1 read */
            ret = joypad1_read();
        }
    }

    return ret | cart_cpu_read(addr);

}

void cpu_mem_write(unsigned short addr, unsigned char data) {

    if (addr < 0x2000) {
        internal_ram[addr & 0x7FF] = data;
    } else if (addr < 0x2008) {
        /* ppu registers */
        ppu_reg_write(addr&7, data);
    } else if (addr >= 0x4000 && addr < 0x4017) {
        /* misc registers */
        if (addr < 0x4014) {
            /* audio */
            apu_reg_write(addr & 0x1F, data);
        } else if (addr == 0x4014) {
            /* sprite DMA */
            do_dma(data*0x100);
        } else if (addr == 0x4015) {
            /* audio */
            apu_reg_write(addr & 0x1F, data);
        } else if (addr == 0x4016) {
            /* controller strope */
            joypad_write(data);
        } else if (addr == 0x4017) {
            /* audio */
            apu_reg_write(addr & 0x1F, data);
        }
    }

    cart_cpu_write(addr, data);

}

char hflg = 0;

unsigned char ppu_mem_read(unsigned short addr) {

    unsigned char ret = 0;
    addr &= 0x3FFF;
    if (addr < 0x2000) {
        /* do nothing */
    } else if (addr & 0x0400) {
        /* nametable 2 */
        ret = namtab2[addr&0x3FF];
    } else {
        /* nametable 1 */
        ret = namtab1[addr&0x3FF];
        /*if (hflg)
            printf("name table read! %04X:%02X\n", addr, ret);*/
    }
    return ret | cart_ppu_read(addr);

}

void ppu_mem_write(unsigned short addr, unsigned char data) {
    addr &= 0x3FFF;

    if (addr < 0x2000) {
        /* do nothing */
    } else if (addr & 0x0400) {
        /* nametable 2 */
        namtab2[addr&0x3FF] = data;
    } else {
        /* nametable 1 */
        namtab1[addr&0x3FF] = data;
        /*fprintf(stderr, " <ppu write %04X:%02X>\n", addr, data);*/
        hflg = 1;
    }

    cart_ppu_write(addr, data);
}

void do_dma(unsigned short addr) {

    int i;
    for (i = 0; i < 256; i++) {
        cpu_mem_write(0x2004, cpu_mem_read(addr+i));
        /*fprintf(stderr, "DMA %04X: %02X\n", addr+i, cpu_mem_read(addr+i));*/
    }

}

void mem_init() {
    int i;
    for (i = 0; i < sizeof(internal_ram); i++)
        internal_ram[i] = 0xFF;
}

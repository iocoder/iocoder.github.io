#include "vga.h"
#include "string.h"

int  *dmp = (int *)  0x2000;
char *vga = (char *) 0x6000;
int loc = 160*3;
char attr      = 0x1F;
char fmt_attr  = 0x1F;
char scan_attr = 0x1E;

void clear_screen(char attr) {
    int i = loc = 160*3;
    while (i < 160*28) {
        vga[i++] = 0;
        vga[i++] = attr;
    }
}

void print_char(char c, char attr) {
    if (c == '\n') {
        loc = ((loc+160)/160)*160;
    } else if (c == '\b') {
        if (loc > 160*3+2)
            loc -= 2;
    } else {
        vga[loc++] = c;
        vga[loc++] = attr;
    }
    if (loc == 160*28) {
        __asm__("pha           ");
        __asm__("lda #$1F      ");
        __asm__("jsr _scroll_up");
        __asm__("pla           ");
        loc = 160*27;
    }
}

void print_int(int num, char attr) {

    char digits[10];
    int i = 0;
    if (!num) {
        digits[i++] = 0;
    } else {
        while (num) {
            digits[i++] = num%10;
            num /= 10;
        }
    }
    while (--i >= 0)
        print_char("0123456789"[digits[i]], attr);

}

void print_hex(int num, char attr) {
    print_char('$', attr);
    print_char("0123456789ABCDEF"[(num>>12)&0xF], attr);
    print_char("0123456789ABCDEF"[(num>> 8)&0xF], attr);
    print_char("0123456789ABCDEF"[(num>> 4)&0xF], attr);
    print_char("0123456789ABCDEF"[(num>> 0)&0xF], attr);
}

void print_str(char *str, char attr) {
    int i = 0;
    while (str[i])
        print_char(str[i++], attr);
}

void print_hf(int line, char *str, char attr) {
    int i;
    int j = line*160;
    int spaces = (80-str_len(str))/2;
    for (i = 0; i < spaces; i++) {
        vga[j++] = ' ';
        vga[j++] = attr;
    }
    for (i = 0; i < str_len(str); i++) {
        vga[j++] = str[i];
        vga[j++] = attr;
    }
    for (i = 0; i < 80-spaces-str_len(str); i++) {
        vga[j++] = ' ';
        vga[j++] = attr;
    }
}

void print_fmt(char *fmt, ...) {
    int arg_id = 0, i;
    void *addr = &fmt;
    for (i = 0; fmt[i] != 0; i++) {
        if (fmt[i] == '%') {
            switch (fmt[++i]) {
                case 'c':
                    addr = (void *)(((int) addr)-2);
                    print_char(*((char *) addr), fmt_attr);
                    break;

                case 'd':
                    addr = (void *)(((int) addr)-2);
                    print_int(*((int *) addr), fmt_attr);
                    break;

                case 'x':
                    addr = (void *)(((int) addr)-2);
                    print_hex(*((int *) addr), fmt_attr);
                    break;

                case 's':
                    addr = (void *)(((int) addr)-2);
                    print_str(*((char **) addr), fmt_attr);
                    break;

                default:
                    break;
            }
        } else {
            print_char(fmt[i], fmt_attr);
        }
    }
}

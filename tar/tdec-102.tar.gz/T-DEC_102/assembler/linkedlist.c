/* Linked List Code File */

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h> /* for debugging purposes */

#include "linkedlist.h"

/***************************************************************************/
/*                          linkedlist_init()                              */
/***************************************************************************/

void linkedlist_init(linkedlist *this) {
    this->head = NULL;
    this->size = 0;
}

/***************************************************************************/
/*                           linkedlist_add()                              */
/***************************************************************************/

void linkedlist_add(linkedlist *this, int index, void *element) {

    int i;
    SNode *node;
    SNode *ptr;

    if (index < 0 || index > this->size) {
        /* printf("linkedlist_add(): Index out of bounds.\n"); */
    } else if (!index) {
        node = malloc(sizeof(SNode));
        node->next = this->head;
        node->val = element;
        this->head = node;
        this->size++;
    } else {
        node = malloc(sizeof(SNode));
        node->val = element;
        i = 1;
        ptr = this->head;
        while (i++ < index)
            ptr = ptr->next;
        /* now ptr refers to the element after which
         * the "node" should be inserted.
         */
        node->next = ptr->next;
        ptr->next = node;
        this->size++;
    }
}

/***************************************************************************/
/*                         linkedlist_addLast()                            */
/***************************************************************************/

void linkedlist_addLast(linkedlist *this, void *element) {
    linkedlist_add(this, this->size, element);
}

/***************************************************************************/
/*                            linkedlist_get()                             */
/***************************************************************************/

void *linkedlist_get(linkedlist *this, int index) {
    if (index < 0 || index >= this->size) {
        /* warning("linkedlist_get(): Index out of bounds.\n"); */
        return NULL;
    } else {
        SNode *ptr = this->head;
        int i = 0;
        while (i++ < index)
            ptr = ptr->next;
        return ptr->val;
    }
}

/***************************************************************************/
/*                           linkedlist_set()                              */
/***************************************************************************/

void linkedlist_set(linkedlist *this, int index, void *element) {
    if (index < 0 || index >= this->size) {
        /* warning("linkedlist_set(): Index out of bounds.\n"); */
    } else {
        SNode *ptr = this->head;
        int i = 0;
        while (i++ < index)
            ptr = ptr->next;
        ptr->val = element;
    }
}

/***************************************************************************/
/*                           linkedlist_clear()                            */
/***************************************************************************/

void linkedlist_clear(linkedlist *this) {
    while(this->size)
        linkedlist_remove(this, 0);
}

/***************************************************************************/
/*                          linkedlist_isEmpty()                            */
/***************************************************************************/

bool linkedlist_isEmpty(linkedlist *this) {
    return this->size ? true : false;
}

/***************************************************************************/
/*                           linkedlist_remove()                           */
/***************************************************************************/

void linkedlist_remove(linkedlist *this, int index) {

    int i;
    SNode *node;
    SNode *ptr;

    if (index < 0 || index >= this->size) {
        /* warning("linkedlist_remove(): Index out of bounds.\n"); */
    } else if (!index) {
        node = this->head;
        this->head = node->next;
        /* NOTE: ptr->val is to be released by the caller. */
        free(node);
        this->size--;
    } else {
        i = 1;
        ptr = this->head;
        while (i++ < index)
            ptr = ptr->next;
        /* now ptr refers to the element after which
         * the "node" to be removed exists.
         */
        node = ptr->next;
        ptr->next = node->next;
        /* NOTE: ptr->val is to be released by the caller. */
        free(node);
        this->size--;
    }
}

/***************************************************************************/
/*                           linkedlist_size()                             */
/***************************************************************************/

int linkedlist_size(linkedlist *this) {
    return this->size;
}

/***************************************************************************/
/*                          linkedlist_sublist()                           */
/***************************************************************************/

linkedlist linkedlist_sublist(linkedlist *this, int fromIndex, int toIndex) {

    linkedlist ret;
    int i = 0;
    SNode *ptr;

    /* initialize the return list */
    linkedlist_init(&ret); /* DS = ES = SS :D */

    /* check borders: */
    if (fromIndex < 0 || fromIndex >= this->size) {
        /* warning("linkedlist_sublist(): fromIndex out of bounds.\n"); */
        return ret;
    }

    if (toIndex < 0 || toIndex >= this->size) {
        /* warning("linkedlist_sublist(): toIndex out of bounds.\n"); */
        return ret;
    }

    if (toIndex < fromIndex) {
        /* warning("linkedlist_sublist(): indices are invalid.\n"); */
        return ret;
    }

    /* do the loop */
    ptr = this->head;
    while (i <= toIndex) {
        if (i >= fromIndex)
            linkedlist_addLast(&ret, ptr->val);
        ptr = ptr->next;
        i++;
    }
    return ret;

}

/***************************************************************************/
/*                          linkedlist_contains()                          */
/***************************************************************************/

bool linkedlist_contains(linkedlist *this, void *o) {
    SNode *ptr = this->head;
    while (ptr) {
        if (ptr->val == o)
            return true;
        ptr = ptr->next;
    }
    return false;
}

/***************************************************************************/
/*                            linkedlist_print()                           */
/***************************************************************************/

void linkedlist_print(linkedlist *this) {
    SNode *ptr;
    printf("SLL(%d): ", this->size);
    ptr = this->head;
    if (ptr == NULL)
        printf("(null)");
    while (ptr) {
        printf("%s%p", ptr == this->head ? "":" -> ", ptr->val);
        ptr = ptr->next;
    }
    printf("\n");
}

#include <stdio.h>
#include <stdlib.h>

#include "cartridge.h"

unsigned char *prgrom = NULL;
unsigned int prgrom_size = 0;

unsigned char *prgram = NULL;
unsigned int prgram_size = 0;

unsigned char *vram = NULL;
unsigned int vram_size = 0;

unsigned char *vrom = NULL;
unsigned int vrom_size = 0;

unsigned char *trainer = NULL;
unsigned int trainer_size = 0;

unsigned char map_reg = 0;

unsigned char mapper = 0;

unsigned char cart_cpu_read(unsigned short addr) {

    unsigned char ret = 0;
    if (mapper == 0) {
        if (addr >= 0x6000 && addr < 0x8000) {
            ret = prgram[addr & 0x1FFF];
        } else if (addr >= 0x8000) {;
            ret = prgrom[(addr & 0x7FFF)%prgrom_size];
        }
    } else if (mapper == 2) {
        if (addr >= 0x8000 && addr < 0xC000)
            ret = prgrom[(map_reg&0x07)*16*1024+(addr&0x3FFF)];
        else if (addr >= 0xC000)
            ret = prgrom[7*16*1024+(addr&0x3FFF)];
    }
    return ret;

}

void cart_cpu_write(unsigned short addr, unsigned char data) {

    if (mapper == 0) {
        if (addr >= 0x6000 && addr < 0x8000) {
            prgram[addr & 0x1FFF] = data;
        } else if (addr >= 0x8000) {
            /* no write to ROM */
        }
    } else if (mapper == 2) {
        if (addr >= 0x8000) {
            map_reg = data;
        }
    }

}

unsigned char cart_ppu_read(unsigned short addr) {

    unsigned char ret = 0;

    if (mapper == 0) {
        if (addr < 0x2000) {
            ret = vrom[addr];
        }
    } else if (mapper == 2) {
        if (addr < 0x2000) {
            ret = vram[addr];
        }
    }

    return ret;

}

void cart_ppu_write(unsigned short addr, unsigned char data) {

    if (mapper == 0) {
        if (addr < 0x2000) {
            /*vrom[addr] = data;*/
        }
    } else if (mapper == 2) {
        if (addr < 0x2000) {
            vram[addr] = data;
        }
    }

}

int cart_load(char *nesfname) {

    FILE *nesfile;
    unsigned char header[16] = {0};
    unsigned int prgroms, vroms;
    int i, j;

    /* open the file */
    if (!(nesfile = fopen(nesfname, "r"))) {
        fprintf(stderr, "Error: Cannot open the file!\n");
        return -2;
    }

    /* read the header */
    fread(header, 16, 1, nesfile);

    /* read the magic code */
    if (header[0] != 'N' || header[1] != 'E' ||
        header[2] != 'S' || header[3] != 0x1A) {
        /* not a valid magic code */
        fprintf(stderr, "Error: Not a valid NES file!\n");
        return -3;
    }

    /* examine PRG-ROM: */
    prgroms = header[4];
    prgrom_size = prgroms * 16 * 1024;
    prgrom = malloc(prgrom_size * sizeof(unsigned char));
    printf("- Number of 16KB PRG-ROMs: %d\n", prgroms);
    printf("  PRG-ROM appears at 0x8000-0xFFFF (32K) of the CPU.\n\n");

    /* examine PRG-RAM */
    prgram_size = (header[8] ? header[8] : 1) * 8 * 1024;
    prgram = malloc(prgram_size * sizeof(unsigned char));
    printf("- Number of 8KB PRG-RAMs: %d\n", header[8]);
    printf("  PRG-RAM appears at 0x6000-0x7FFF (8K) of the CPU.\n");
    printf("  0 means undefined. If 0, assume there is one 8KB PRG-RAM.\n");
    printf("  Is battery backed: %s.\n\n", header[6]&2?"Yes":"No");

    /* examine trainer */
    trainer_size = ((header[6] & 4) ? 1 : 0) * 512;
    if (trainer_size)
        trainer = malloc(trainer_size * sizeof(unsigned char));
    printf("- Trainer/Patch: %s\n", (header[6] & 4) ? "Yes":"No");
    printf("  Trainer appears at 0x7000-0x71FF (512 bytes) of the CPU.\n\n");

    /* examine VROMs */
    vroms = header[5];
    if (vroms) {
        vrom_size = vroms * 8 * 1024;
        vrom = malloc(vrom_size * sizeof(unsigned char));
    }
    printf("- Number of 8KB VROMs: %d\n", vroms);
    printf("  Note that there might also be a VRAM on the cartridge...\n");
    printf("  This depends on the cartridge type (see mapper type below).\n");
    printf("  VROMs/VRAMs appear at 0x0000-0x1FFF (8K) of the PPU.\n\n");

    /* mapper type */
    mapper = (header[6]>>4)|(header[7]&0xF0);
    printf("- Mapper type: %d\n", mapper);
    if (mapper == 2) {
        int i;
        vram_size = 8*1024;
        vram = malloc(vram_size * sizeof(unsigned char));
        for (i = 0; i < vram_size; i++)
            vram[i] = 0;
    }

    /* read trainer */
    if (trainer_size)
        fread(trainer, trainer_size, 1, nesfile);

    /* read PRG-ROMs */
    if (prgrom_size)
        fread(prgrom, prgrom_size, 1, nesfile);

    /* read VROMs */
    if (vrom_size)
        fread(vrom, vrom_size, 1, nesfile);

    /* close NES file */
    fclose(nesfile);

}

/* audio processing unit */

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <math.h>

/*****************************************************************************/
/*                             REGISTERS                                     */
/*****************************************************************************/

/*******************/
/* Frame Sequencer */
/*******************/
/* frame sequencer is clocked with 240Hz,
 * so each frame tick takes 4.167ms. it is used
 * to clock the length counters, sweep units,
 * envelopes, and triangle's linear counter.
 * it doesn't clock the timer (which clocks
 * the waveform generator). The timer
 * is clocked by a 1.79MHz clock (0.558us)
 * and contains an internal divider that
 * is controlled by the sweep unit. the
 * timer clocks the waveform generator.
 * Every frame tick contains 33.336 samples. every
 * sample takes 0.125ms, which is 224
 * clocks from the 1.79 source.
 */
 /* TODO: Some games (e.g. Super Mario Bros., Zelda) manually synchronize
  * the IRQ signal by writing $C0 or $FF to $4017 once per frame.
  */
unsigned char sequencer_mode = 0; /* 0: 4-step, 1: 5-step */
unsigned char sequencer_step = 0; /* next step */
unsigned char sequencer_restart = 0; /* sequencer restart? */
unsigned char irq_disable = 0;
unsigned char irq_triggered = 0;
unsigned int  clock_counter = 0; /* 1.79MHz clock counter for sampling 224 */

/*******************/
/* Length counters */
/*******************/
unsigned char lc_lookup[] = {
    0x0A, 0xFE,
    0x14, 0x02,
    0x28, 0x04,
    0x50, 0x06,
    0xA0, 0x08,
    0x3C, 0x0A,
    0x0E, 0x0C,
    0x1A, 0x0E,
    0x0C, 0x10,
    0x18, 0x12,
    0x30, 0x14,
    0x60, 0x16,
    0xC0, 0x18,
    0x48, 0x1A,
    0x10, 0x1C,
    0x20, 0x1E
};

struct {
    unsigned char halt;    /* length counter halt */
    unsigned char counter; /* the counter value */
} lc[4] = {0};

/*************/
/* Envelopes */
/*************/
struct {
    unsigned char loop;    /* 0: no loop, 1: infinite loop */
    unsigned char mode;    /* 0: constant volume, 1: envelope enable */
    unsigned char n;       /* the constant volume, or period */
    unsigned char counter; /* the envelope internal counter */
    unsigned char divider; /* the envelope internal divider */
} env[3] = {0};

/**********/
/* Timers */
/**********/
struct {
    unsigned short period;  /* the actual period */
    unsigned short counter; /* internal counter */
} timer[3] = {0};

/***************/
/* Sweep units */
/***************/
struct {
    unsigned char enable;  /* sweep enable */
    unsigned char p;       /* sweep period */
    unsigned char negate;  /* sweep negate */
    unsigned char shift;   /* sweep shift amount */
    unsigned char counter; /* sweep internal counter */
    unsigned short res;    /* sweep result */
} sweep[3] = {0};

/***********************/
/* Waveform generators */
/***********************/
struct {
    unsigned char enable;   /* enable sound */
    unsigned char duty;     /* duty */
    unsigned char counter;  /* internal counter */
    unsigned char output;   /* output of the generator */
} wave[2] = {0};

/* triangle */
unsigned char tri_linear = 0;
unsigned char tri_lo = 0;
unsigned char tri_hi = 0;
unsigned char tri_enable = 0;

/* noise */
unsigned char noise_vol = 0;
unsigned char noise_lo = 0;
unsigned char noise_hi = 0;
unsigned char noise_enable = 0;

/* DMC */
unsigned char dmc_freq = 0;
unsigned char dmc_raw = 0;
unsigned char dmc_start = 0;
unsigned char dmc_len = 0;
unsigned char dmc_enable = 0;
unsigned char dmc_active = 0;
unsigned char dmc_interrupt = 0;

unsigned char apu_reg_read(unsigned short reg) {

    unsigned char ret;

    if (reg == 0x15) {
        /* read status */
        ret = ((lc[0].counter > 0)<<0)|
              ((lc[1].counter > 0)<<1)|
              ((lc[2].counter > 0)<<2)|
              ((lc[3].counter > 0)<<3)|
              (dmc_active         <<4)|
              (irq_triggered      <<6)|
              (dmc_interrupt      <<7);
        irq_triggered = 0;
    }

}

void apu_reg_write(unsigned short reg, unsigned char data) {

    switch (reg) {
        case 0x00:
            wave[0].duty = data>>6;
            lc[0].halt = (data>>5)&1;
            env[0].loop = (data>>5)&1;
            env[0].mode = !((data>>4)&1);
            env[0].n = data & 0x0F;
            if (!env[0].mode)
                env[0].counter = env[0].n;
            break;

        case 0x01:
            sweep[0].enable = (data>>7)&1;
            sweep[0].p = (data>>4)&7;
            sweep[0].negate = (data>>3)&1;
            sweep[0].shift = data&7;
            break;

        case 0x02:
            timer[0].period = (timer[0].period & 0xFF00) | data;
            break;

        case 0x03:
            lc[0].counter = lc_lookup[(data>>3)&0x1F];
            timer[0].period = ((data&7)<<8) | (timer[0].period & 0xFF);
            printf("lc: halt: %d, counter: %d\n", lc[0].halt, lc[0].counter);
            printf("wave: duty:%d\n", wave[0].duty);
            printf("env: loop: %d, mode: %d, n: %d\n",
                    env[0].loop, env[0].mode, env[0].n);
            printf("sweep: enable:%d, p:%d, negate:%d, shift:%d\n",
                    sweep[0].enable, sweep[0].p, sweep[0].negate,
                    sweep[0].shift);
            printf("timer: period:%d\n", timer[0].period);
            break;

        case 0x04:
            /*sq2_vol = data;*/
            break;

        case 0x05:
            /*sq2_sweep = data;*/
            break;

        case 0x06:
            /*sq2_lo = data;*/
            break;

        case 0x07:
            /*sq2_hi = data;*/
            break;

        case 0x08:
            tri_linear = data;
            break;

        case 0x0A:
            tri_lo = data;
            break;

        case 0x0B:
            tri_hi = data;
            break;

        case 0x0C:
            noise_vol = data;
            break;

        case 0x0E:
            noise_lo = data;
            break;

        case 0x0F:
            noise_hi = data;
            break;

        case 0x10:
            dmc_freq = data;
            break;

        case 0x11:
            dmc_raw = data;
            break;

        case 0x12:
            dmc_start = data;
            break;

        case 0x13:
            dmc_len = data;
            break;

        case 0x15:
            /* sound channel enable bits */
            if (wave[0].enable != (data & 1)) {
                printf("sq1 enable: %d\n", data & 1);
            }
            wave[0].enable = (data & 1) ? 1 : 0;
            wave[1].enable = (data & 2) ? 1 : 0;
            tri_enable = (data & 4) ? 1 : 0;
            noise_enable = (data & 8) ? 1 : 0;
            dmc_enable = (data & 16) ? 1 : 0;
            break;

        case 0x17:
            /* frame counter control */
            sequencer_mode = (data & 0x80) ? 1 : 0;
            irq_disable = (data & 0x40) ? 1 : 0;
            if (data & 0x40)
                irq_triggered = 0;
            sequencer_step = 0;
            sequencer_restart = 1;
            break;

        default:
            break;

    }

}

/*****************************************************************************/
/*                            Audio Logic                                    */
/*****************************************************************************/

unsigned short raw[66] = {0};

unsigned char get_volume(int channel) {

    if (channel == 0) {
        unsigned char volume = env[0].counter;
        if (sweep[0].res < 8 && sweep[0].res > 0x7FF)
            volume = 0;
        if (!wave[0].output)
            volume = 0;
        if (!lc[0].counter)
            volume = 0;
        return volume;
    }

}

void waveform_clk(int i) {

    if (i == 0 || i == 1) {
        unsigned char square[4] = {0x40, 0x60, 0x78, 0x9F};
        unsigned char waveform = square[wave[i].duty];
        wave[i].output = (waveform & (1<<wave[i].counter)) ? 1 : 0;
        if (++wave[i].counter > 7) {
            wave[i].counter = 0;
        }
    }

}

void timer_clk() {

    int i;
    for (i = 0; i < 3; i++) {
        if (timer[i].counter) {
            timer[i].counter--;
        } else {
            timer[i].counter = timer[i].period;
            waveform_clk(i);
        }
    }

}

void envelope_clk() {

    int i;
    for (i = 0; i < 3; i++) {
        if (env[i].mode) {
            if (env[i].divider) {
                env[i].counter--;
            } else {
                env[i].divider = env[i].n;
                if (env[i].counter) {
                    env[i].counter--;
                } else if (env[i].loop) {
                    env[i].counter = 15;
                }
            }
        }
    }

}

void length_counter_clk() {

    int i;
    for (i = 0; i < 4; i++) {
        if ((!lc[i].halt) && lc[i].counter) {
            lc[i].counter--;
        }
    }

}

void tri_linear_counter_clk() {

}

void sweep_clk() {

    int i;
    for (i = 0; i < 3; i++) {
        if (sweep[i].enable && sweep[i].shift) {
            if (sweep[i].counter) {
                sweep[i].counter--;
            } else {
                sweep[i].counter = sweep[i].p;
                sweep[i].res = timer[i].period >> sweep[i].shift;
                if (sweep[i].negate)
                    sweep[i].res = (~sweep[i].res) & 0x7FF;
                if (i == 1)
                    sweep[i].res++;
                if (sweep[i].res >= 8 && sweep[i].res <= 0x7FF)
                    timer[i].period = sweep[i].res;
            }
        }
    }

}

void frame_seuquencer_clk() {

    extern int irq_pulse;

    if (!sequencer_mode) {
        if (sequencer_step == 0) {
            envelope_clk();
            tri_linear_counter_clk();
        } else if (sequencer_step == 1) {
            length_counter_clk();
            sweep_clk();
            envelope_clk();
            tri_linear_counter_clk();
        } else if (sequencer_step == 2) {
            envelope_clk();
            tri_linear_counter_clk();
        } else {
            length_counter_clk();
            sweep_clk();
            envelope_clk();
            tri_linear_counter_clk();
            if (!irq_disable) {
                irq_pulse = 1;
                irq_triggered = 1;
            }
        }
        if (++sequencer_step > 3) {
            sequencer_step = 0;
        }
    } else {
        if (sequencer_step == 0) {
            length_counter_clk();
            sweep_clk();
            envelope_clk();
            tri_linear_counter_clk();
        } else if (sequencer_step == 1) {
            envelope_clk();
            tri_linear_counter_clk();
        } else if (sequencer_step == 2) {
            length_counter_clk();
            sweep_clk();
            envelope_clk();
            tri_linear_counter_clk();
        } else if (sequencer_step == 3) {
            envelope_clk();
            tri_linear_counter_clk();
        } else {

        }
        if (++sequencer_step > 4) {
            sequencer_step = 0;
        }
    }

}

void generate_audio() {

    int i, j;
    for (i = 0; i < sizeof(raw)/sizeof(unsigned short); i++) {
        /* tick the timers 224 times */
        for (j = 0; j < 224/2; j++) {
            timer_clk();
        }
        raw[i] = get_volume(0)*3000/3;
    }

}

/*****************************************************************************/
/*                             SAMPLING                                      */
/*****************************************************************************/


int apu_loop(void *data) {

    Mix_Chunk *chunk;
    int i, time = 0, freq = 100;

    /* load chunk */
    chunk = Mix_QuickLoad_RAW((Uint8 *) raw, sizeof(raw));

    /* loop */
    while(1) {
        /* trigger a clock */
        frame_seuquencer_clk();

        /* generate music */
        generate_audio();

        /* play music */
        Mix_PlayChannel(0, chunk, -1);

        /* wait */
        while (Mix_Playing(0) && (!sequencer_restart));

        /* stop */
        Mix_Pause(-1);

        /* clear restart flag */
        sequencer_restart = 0;
    }

}

/*****************************************************************************/
/*                           INITIALIZATION                                  */
/*****************************************************************************/

void apu_init() {

    /* initialize audio */
    if (Mix_OpenAudio(16000, AUDIO_U16LSB, 2, 2048) < 0) {
        printf("Can't initialize audio!");
    }

    /* create APU thread */
    SDL_CreateThread(apu_loop, NULL);

}

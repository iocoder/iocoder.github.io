#ifndef _6502COMP_MEM_H
#define _6502COMP_MEM_H

void mem();

#endif


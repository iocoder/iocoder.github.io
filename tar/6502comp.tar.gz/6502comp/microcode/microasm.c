/* Microassembler for 6502 Microcode */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct uinstr {
    /* micro instruction */
#define TYPE_TRANS      0 /* register transfer */
#define TYPE_LOOKUP     1 /* lookup instruction */
#define TYPE_IF         2 /* jump if 0/1  */
    int type;
    /* register transfer */
    int reg1;
    int reg2;
    /* If condition & jump */
    int val;  /* 0/1 */
    int indx; /* multiplexer index */
    char symbol[32];
    /* lookup data */
    int offset;
    /* next micro-instruction in ROM */
    struct uinstr *next;
} uinstr_t;

typedef struct symbol {
    char symbol[32];
    unsigned short value;
    struct symbol *next;
} symbol_t;

/* Micro-instruction format:
 * --------------------------
 * bit0-1: Instruction Type:
 *         00: REG
 *         01: LOOKUP
 *         10: JUMP IF 0
 *         11: JUMP IF 1
 *
 * FOR REG:
 * bit2-6:   Read Signal
 * bit7-11:  Write Signal
 * bit12-15: 0000
 *
 * FOR LOOKUP:
 * bit2-4:   offset
 * bit5-15:  00000000000
 *
 * FOR JUMPING:
 * bit2-4:   COND INDEX
 * bit5-15:  NEXT VALUE OF SEQ if cond matches.
 */

/* Hardware Implementation:
 * -------------------------
 * Read Signal Decoder and Write Signal Decoder
 * are only enabled when bit0-1 = 00.
 *
 * Condition MUX and SEQ triggers:
 *
 *       BIT1
 *        |
 *     *----\
 *   1-|  E  \
 *   C-|      \
 *   Z-|       \        *-----*
 *   N-|        |___M___|  =  |____BIT0
 *   V-|        |       *-----*
 * NMI-|       /           |
 * IRQ-|      /            |   *---\
 *   0-| CTL /             \---|    \
 *     *----/                  | AND |--- SEQ=NEXT
 *       |||             BIT1--|    /
 *       432                   *---/
 *
 *                             *---\
 *                       BIT0--|    \
 *                             | AND |--- SEQ=LOOKUP+OFF
 *                      !BIT1--|    /
 *                             *---/
 *
 * IF BIT1=0 and BIT0=1 Then SEQ=LOOKUP+OFF
 * IF BIT1=1 and BIT0=M Then SEQ=NEXT
 * Else Then SEQ=SEQ+1
 *
 */

/* Mapping:
 * ---------
 * Register Transfer: 0000WWWWWRRRRR00
 * IF GOTO:           NNNNNNNNNNNIII1V
 * GOTO:              NNNNNNNNNNN00011
 * LOOKUP:            00000000000FFF01
 */

uinstr_t *first_uinstr = NULL;
uinstr_t *last__uinstr = NULL;
symbol_t *first_symbol = NULL;
symbol_t *last__symbol = NULL;

char buf[4096];
unsigned short lookup[256] = {0};

int isValidHex(char *str) {
    if (strlen(str) != 4 || str[0] != '0' || str[1] != 'x')
        return 0;
    if (!((str[2]>='0' && str[2]<='9') || (str[2]>='A' && str[2]<='F')))
        return 0;
    if (!((str[3]>='0' && str[3]<='9') || (str[3]>='A' && str[3]<='F')))
        return 0;
    return 1;
}

unsigned char parseHex(char *str) {
#define HDIGIT(c) ({c >= 'A' ? (c-'A'+10):(c-'0');})
    return (HDIGIT(str[2])<<4) | HDIGIT(str[3]);
}

int isValidDec(char *str) {
    int i = 0;
    while (str[i]) {
        if (str[i] < '0' || str[i] > '9')
            return 0;
        i++;
    }
    return 1;
}

int isValidReg(char *str) {
    if (strlen(str) != 4 || str[0] != '[' || str[3] != ']')
        return 0;
    if (str[1] < '0' || str[1] > '9')
        return 0;
    if (str[2] < '0' || str[2] > '9')
        return 0;
    return 1;
}

unsigned char parseReg(char *str) {
    return (str[1]-'0')*10 + (str[2]-'0');
}

int isValidLookup(char *str) {
    if (str[0] != 'L' || str[1] != 'o' || str[2] != 'o' ||
        str[3] != 'k' || str[4] != 'u' || str[5] != 'p' ||
        str[6] != '+')
        return 0;
    if (str[7] < '0' || str[7] > '9')
        return 0;
    return 1;
}

int parseLookup(char *str) {
    return str[7] - '0';
}

void addsymbol(char *symbol, unsigned short value) {
    if (!first_symbol) {
        first_symbol = last__symbol = malloc(sizeof(symbol_t));
    } else {
        last__symbol = last__symbol->next = malloc(sizeof(symbol_t));
    }
    strcpy(last__symbol->symbol, symbol);
    last__symbol->value = value;
    last__symbol->next = NULL;
}

unsigned short getsymbol(char *symbol) {
    symbol_t *p = first_symbol;
    while (p && strcmp(p->symbol, symbol))
        p = p->next;
    if (!p) {
        fprintf(stderr, "Symbol not found: %s\n", symbol);
        exit(-4);
    }
    return p->value;
}

void adduinstr(uinstr_t uinstr) {
    if (!first_uinstr) {
        first_uinstr = last__uinstr = malloc(sizeof(uinstr_t));
    } else {
        last__uinstr = last__uinstr->next = malloc(sizeof(uinstr_t));
    }
    *last__uinstr = uinstr;
}

void listing() {
    symbol_t *t = first_symbol;
    while (t) {
        printf("sym: %s, val: %d\n", t->symbol, t->value);
        t = t->next;
    }
}

void pass1(FILE *inf) {
    uinstr_t cur = {0};
    unsigned short LC = 0; /* location counter */
    int line = 0; /* line counter */
    char *tok;
    while (fgets(buf, sizeof(buf)-1, inf)) {
        /* a line is read */
        line++;
        if (LC == 2048) {
           /* fprintf(stderr, "Line %d: Microprogram overflow.\n", line);
            exit(-3);*/
        }
        if (strchr(buf, ':')) {
            /* label */
            if (strchr(buf, '=')) {
                /* lookup label */
                if ((tok = strtok(buf, " \t\n=:")) == NULL) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                if ((tok = strtok(NULL, " \t\n=:")) == NULL) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                if (!isValidHex(tok)) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                lookup[parseHex(tok)] = LC;
            } else {
                /* ordinary label */
                if ((tok = strtok(buf, " \t\n:")) == NULL) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                addsymbol(tok, LC);
            }
        } else {
            if (strstr(buf, "If")) {
                /* If (INDX = VAL) Goto symbol */
                cur.type = TYPE_IF;
                cur.reg1 = cur.reg2 = 0;
                /* If */
                tok = strtok(buf, " \t\n");
                if ((!tok) || strcmp(tok, "If")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* ( */
                tok = strtok(NULL, " \t\n");
                if ((!tok) || strcmp(tok, "(")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* INDX */
                tok = strtok(NULL, " \t\n");
                if ((!tok)||(!isValidDec(tok))||(cur.indx=atoi(tok))>7) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* = */
                tok = strtok(NULL, " \t\n");
                if ((!tok) || strcmp(tok, "=")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* VAL */
                tok = strtok(NULL, " \t\n");
                if ((!tok)||(!isValidDec(tok))||(cur.val=atoi(tok))>1) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* ) */
                tok = strtok(NULL, " \t\n");
                if ((!tok) || strcmp(tok, ")")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* Goto */
                tok = strtok(NULL, " \t\n");
                if ((!tok) || strcmp(tok, "Goto")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* symbol */
                tok = strtok(NULL, " \t\n");
                if (!tok) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                strcpy(cur.symbol, tok);
                /* period */
                tok = strtok(NULL, " \t\n");
                if (tok) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
            } else if (strstr(buf, "Goto")) {
                /* Goto symbol */
                cur.type = TYPE_IF;
                cur.reg1 = cur.reg2 = 0;
                cur.indx = 0;
                cur.val  = 1;
                /* Goto */
                tok = strtok(buf, " \t\n");
                if ((!tok) || strcmp(tok, "Goto")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* Symbol */
                tok = strtok(NULL, " \t\n");
                if (!tok) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                strcpy(cur.symbol, tok);
                /* period */
                tok = strtok(NULL, " \t\n");
                if (tok) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
            } else if (strstr(buf, "Lookup")) {
                /* Lookup+# */
                cur.type = TYPE_LOOKUP;
                cur.reg1 = cur.reg2 = 0;
                cur.indx = cur.val = 0;
                strcpy(cur.symbol, "");
                /* Lookup+# */
                tok = strtok(buf, " \t\n");
                if (!tok || !isValidLookup(tok) || parseLookup(tok)>7) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                cur.offset = parseLookup(tok);
                /* period */
                tok = strtok(NULL, " \t\n");
                if (tok) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
            } else if (strstr(buf, "<--")) {
                /* [REG] <-- [REG] */
                cur.type = TYPE_TRANS;
                cur.indx = cur.val = 0;
                strcpy(cur.symbol, "");
                /* [REG] */
                tok = strtok(buf, " \t\n");
                if ((!tok) || (!isValidReg(tok)) || parseReg(tok) > 31) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                cur.reg1 = parseReg(tok);
                /* <-- */
                tok = strtok(NULL, " \t\n");
                if (!tok || strcmp(tok, "<--")) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                /* [REG] */
                tok = strtok(NULL, " \t\n");
                if ((!tok) || (!isValidReg(tok)) || parseReg(tok) > 31) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
                cur.reg2 = parseReg(tok);
                /* period */
                tok = strtok(NULL, " \t\n");
                if (tok) {
                    fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                    exit(-3);
                }
            } else {
                /* Invalid syntax */
                fprintf(stderr, "Line %d: Invalid Syntax.\n", line);
                exit(-3);
            }
            /* add instruction */
            adduinstr(cur);
            /* update location counter */
            LC++;
        }
    }
    printf("Parsed %d micro-instructions.\n", LC);
}

void pass2(FILE *of, FILE *lf) {

    uinstr_t *p = first_uinstr;
    int i;

    /* translate */
    while (p) {
        unsigned short instr;
        if (p->type == TYPE_IF) {
            instr = 2 | p->val;
            instr |= (p->indx)<<2;
            instr |= getsymbol(p->symbol)<<5;
        } else if (p->type == TYPE_TRANS) {
            instr = (p->reg2<<2) | (p->reg1<<7);
        } else {
            instr = 1 | (p->offset << 2);
        }
        fwrite(&instr, sizeof(instr), 1, of);
        p = p->next;
    }

    /* lookup ROM */
    for (i = 0; i < 256; i++) {
        fwrite(&lookup[i], sizeof(lookup[i]), 1, lf);
    }

}

int main(int argc, char *argv[]) {

    FILE *inf, *of, *lf;

    if (argc != 4) {
        fprintf(stderr, "Invalid arguments!\n");
        return -1;
    }

    if (!(inf = fopen(argv[1], "r"))) {
        fprintf(stderr, "Cannot open input file!\n");
        return -2;
    }

    if (!(of = fopen(argv[2], "w"))) {
        fprintf(stderr, "Cannot open ouput file!\n");
        return -2;
    }

    if (!(lf = fopen(argv[3], "w"))) {
        fprintf(stderr, "Cannot open lookup file!\n");
        return -2;
    }

    pass1(inf);
    pass2(of, lf);

    fclose(inf);
    fclose(of);
    fclose(lf);

    return 0;

}

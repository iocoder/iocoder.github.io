/* instructions */

/* register names */
char *regs[] = {
    "R0", "R1", "R2", "R3",
    "R4", "R5", "R6", "R7",
    0
};

/* instruction formats and opcodes */
char *isa[] = {
    /* JMP Direct - No condition */
    "JMP","NUM",0, "00000000:8","OP1:16",0,

    /* JMP Direct - If Zero Flag = x */
    "JZ", "NUM",0, "00110000:8","OP1:16",0,
    "JNZ","NUM",0, "00100000:8","OP1:16",0,

    /* JMP Indirect */
    "JMP","REG",":","REG",0, "01000000:8","OP2:4","OP1:4",0,

    /* 1000 - load with immediate */
    "MOV","REG",",","NUM",0, "OP1:4","1000:4","OP2:8",0,

    /* 1001 - load from memory, direct */
    "MOV","REG",",","[","NUM","]",0, "OP1:4","1001:4","OP2:16",0,

    /* 1010 - load from memory, indirect */
    "MOV","REG",",","[","REG",":","REG","]",0,
          "OP1:4","1010:4","OP3:4","OP2:4",0,

    /* 1011 - store direct */
    "MOV","[","NUM","]",",","REG",0, "OP2:4","1011:4","OP1:16",0,

    /* 1100 - store indirect */
    "MOV","[","REG",":","REG","]",",","REG",0,
          "OP3:4","1100:4","OP2:4","OP1:4",0,

    /* 1101 - load register by register */
    "MOV","REG",",","REG",0, "11010000:8","OP1:4","OP2:4",0,

    /* 1110 - ALU */
    "ADD","REG",",","REG",0, "11100000:8","OP1:4","OP2:4",0,
    "SUB","REG",",","REG",0, "11100001:8","OP1:4","OP2:4",0,
    "AND","REG",",","REG",0, "11100010:8","OP1:4","OP2:4",0,
    "OR", "REG",",","REG",0, "11100011:8","OP1:4","OP2:4",0,
    "NOT","REG",0,           "11100100:8","OP1:4","OP1:4",0,
    "XOR","REG",",","REG",0, "11100101:8","OP1:4","OP2:4",0,
    "SHL","REG",0,           "11100110:8","OP1:4","OP1:4",0,
    "SHR","REG",0,           "11100111:8","OP1:4","OP1:4",0,

    /* 1111 - ALU with immediate */
    "ADD","REG",",","NUM",0, "11110000:8","OP1:4","0000:4","OP2:8",0,
    "SUB","REG",",","NUM",0, "11110001:8","OP1:4","0000:4","OP2:8",0,
    "AND","REG",",","NUM",0, "11110010:8","OP1:4","0000:4","OP2:8",0,
    "OR", "REG",",","NUM",0, "11110011:8","OP1:4","0000:4","OP2:8",0,
    "XOR","REG",",","NUM",0, "11110101:8","OP1:4","0000:4","OP2:8",0,
    0
};

/* T-DEC architecture: */

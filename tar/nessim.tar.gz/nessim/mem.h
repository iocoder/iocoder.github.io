#ifndef NESSIM_MEM_H
#define NESSIM_MEM_H

unsigned char cpu_mem_read(unsigned short addr);
void cpu_mem_write(unsigned short addr, unsigned char data);
unsigned char ppu_mem_read(unsigned short addr);
void ppu_mem_write(unsigned short addr, unsigned char data);
void do_dma(unsigned short addr);

extern unsigned char ppu_cr1; /* PPU Control Register 1 */
extern unsigned char ppu_cr2; /* PPU Control Register 2 */
extern unsigned char ppu_sr;  /* PPU Status Register */

extern unsigned short Loopy_V; /* VRAM address */
extern unsigned short Loopy_T; /* current tile */
extern unsigned char  Loopy_X; /* current X in the tile */

extern unsigned char sprite_attr[];

#endif

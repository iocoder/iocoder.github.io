#include <stdio.h>

int main(int argc, char *argv[]) {

    FILE *f1, *f2, *f3, *f4;
    char w, x, y, z;

    if (argc != 5) {
        fprintf(stderr, "Invalid arguments\n");
        return -1;
    }

    f1 = fopen(argv[1], "w");
    f2 = fopen(argv[2], "w");
    f3 = fopen(argv[3], "w");
    f4 = fopen(argv[4], "w");

    while (scanf("%c%c%c%c", &w, &x, &y, &z) != EOF) {
        fprintf(f1, "%c", w);
        fprintf(f2, "%c", x);
        fprintf(f3, "%c", y);
        fprintf(f4, "%c", z);
    }

    fclose(f1);
    fclose(f2);
    fclose(f3);
    fclose(f4);

    return 0;

}

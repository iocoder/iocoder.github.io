#ifndef NESSIM_CLOCK_H
#define NESSIM_CLOCK_H

void clock_handler();

#endif

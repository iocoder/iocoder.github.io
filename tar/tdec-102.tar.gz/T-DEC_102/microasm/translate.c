/* Translation process consists of 2 passes:
 * Pass 1: - Translate RTL to control signals
 *         - Solve all labels.
 * Pass 2: - Set next state values of every state.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "microasm.h"

/****************************************************************************/
/*                           next_statement()                               */
/****************************************************************************/

statement_t *next_statement(FILE *rtl_file, int line_index) {

    /* buffer to read the line: */
    char buf[MAX_LINE_SIZE+1];

    /* token variable */
    char *tok;

    /* Microinstruction has 2 operands: */
    char *operand1, *operand2;

    /* temporary variable for solving labels */
    char *label;

    /* loop counter */
    int i;

    /* statement data structure */
    statement_t *statement;

    /* do the read! */
    if (fgets(buf, MAX_LINE_SIZE, rtl_file) == NULL) {
        /* End of File */
        return NULL;
    }

    /* allocate statement structure: */
    statement = alloc_statement();

    /* tokenize the read line: */
    tok = strtok (buf, " \t\n\r(=)");

    /* first token is special, really :D */
    if (tok == NULL || tok[0] == '#') {

        /* EMPTY LINE OR COMMENT! */
        statement->type = STATEMENT_EMPTY;

    } else if (tok[strlen(tok)-1] == ':') {

        /* LABEL! */
        statement->type = STATEMENT_LABEL;

        /* copy tok to heap: */
        label = malloc(strlen(tok));
        for (i = 0; i < strlen(tok)-1; i++)
            label[i] = tok[i];
        label[i] = 0;

        /* create token array: */
        statement->tokens = malloc(1*sizeof(char *));
        statement->tokens[0] = label;
        statement->tokens_count = 1;

    } else if (!strcmp(tok, "If")) {

        /* IF CONDITIONAL! */
        statement->type = STATEMENT_IF;

        /* if statement should consist of 5 tokens */
        statement->tokens = malloc(5*sizeof(char *));

        /* loop on all tokens */
        while (tok && statement->tokens_count < 5) {
            statement->tokens[statement->tokens_count]=malloc(strlen(tok)+1);
            strcpy(statement->tokens[statement->tokens_count++], tok);
            tok = strtok(NULL, " \t\n\r(=)");
        }

        /* no enough tokens? */
        if (statement->tokens_count < 5) {
            fprintf(stderr, "Error in line %d: ", line_index+1);
            fprintf(stderr, "Invalid \'If\' statement.\n");
            statement->type = STATEMENT_ERROR;
            return statement;
        }

    } else if (!strcmp(tok, "Goto")) {

        /* GOTO STATEMENT is treated as a condition-free if statement*/
        statement->type = STATEMENT_IF;

        /* create token array: */
        statement->tokens = malloc(5*sizeof(char *));

        /* copy first token */
        statement->tokens[0] = malloc(strlen(tok)+1);
        strcpy(statement->tokens[0], tok);
        statement->tokens_count++;

        /* condition signal name is empty */
        statement->tokens[1] = malloc(1);
        strcpy(statement->tokens[1], "");
        statement->tokens_count++;

        /* condition signal value is empty */
        statement->tokens[2] = malloc(1);
        strcpy(statement->tokens[2], "");
        statement->tokens_count++;

        /* a padding entry */
        statement->tokens[3] = malloc(1);
        strcpy(statement->tokens[3], "");
        statement->tokens_count++;

        /* load reference name */
        if(!(tok = strtok(NULL, " \t\n\r(=)"))) {
            fprintf(stderr, "Error in line %d: ", line_index+1);
            fprintf(stderr, "Invalid \'Goto\' statement.\n");
            statement->type = STATEMENT_ERROR;
            return statement;
        }

        /* copy reference name */
        statement->tokens[4] = malloc(strlen(tok)+1);
        strcpy(statement->tokens[4], tok);
        statement->tokens_count++;

    } else {

        /* MICROINSTRUCTION! */
        statement->type = STATEMENT_MICROINSTR;

        /* store operand1 */
        operand1 = malloc(strlen(tok)+1);
        strcpy(operand1, tok);

        /* read the operator */
        tok = strtok(NULL, " \t\n\r");
        if (tok == NULL || strcmp(tok, "<--")) {
            fprintf(stderr, "Error in line %d: ", line_index+1);
            fprintf(stderr, "Microinstruction expected.\n");
            statement->type = STATEMENT_ERROR;
            free(operand1);
            return statement;
        }

        /* read next operand: */
        tok = strtok(NULL, " \t\n\r");
        if (tok == NULL) {
            fprintf(stderr, "Error in line %d: ", line_index+1);
            fprintf(stderr, "Microinstruction should have 2 operands.\n");
            statement->type = STATEMENT_ERROR;
            free(operand1);
            return statement;
        }

        /* copy tok to operand2: */
        operand2 = malloc(strlen(tok) + 1);
        strcpy(operand2, tok);

        /* concatenate any other token to operand2: */
        while ((tok = strtok(NULL, " \t\n\r")) != NULL) {
            char *tmp = malloc(strlen(operand2) + strlen(tok) + 1);
            strcpy(tmp, operand2);
            strcpy(&tmp[strlen(operand2)], tok);
            free(operand2);
            operand2 = tmp;
        }

        /* put them in an array: */
        statement->tokens = malloc(2*sizeof(char *));
        statement->tokens[0] = operand1;
        statement->tokens[1] = operand2;
        statement->tokens_count = 2;

    }

    return statement;

}

/****************************************************************************/
/*                               pass1()                                    */
/****************************************************************************/

int pass1(FILE *rtl_file, machine_t *machine) {

    /* current statement: */
    statement_t *statement;

    /* current microinstruction */
    state_t *st;

    /* line counter: */
    int line_index = 0;

    /* read statements: */
    while (statement = next_statement(rtl_file, line_index)) {

        /* syntax error? */
        if (statement->type == STATEMENT_ERROR) {
            free_statement(statement);
            return -3;
        }

        /* in pass1, we care only for microinstructions and labels: */
        if (statement->type == STATEMENT_MICROINSTR) {

            /* maximum count of states reached? */
            if (machine->states_count == machine->max_states) {
                fprintf(stderr, "Error in line %d: ", line_index+1);
                fprintf(stderr, "Maximum count of %s",
                                "microinstructions reached.\n");
                free_statement(statement);
                return -5;
            }

            /* translate RTL to signals: */
            st = rtl_to_signals(machine, statement);

            /* some error */
            if (st == NULL) {
                fprintf(stderr, "Error in line %d: ", line_index+1);
                fprintf(stderr, "Uknown operands.\n");
                free_statement(statement);
                return -4;
            }

            /* no error, store the state into state array. */
            machine->states[machine->states_count++] = st;

        } else if (statement->type == STATEMENT_LABEL) {

            /* add the label to symbol table */
            add_symbol(machine, statement->tokens[0], machine->states_count);

        }

        /* done: */
        free_statement(statement);

        /* this is useful when printing errors to stderr: */
        line_index++;

    }

    /* no error */
    return 0;
}

/****************************************************************************/
/*                               pass2()                                    */
/****************************************************************************/

int pass2(FILE *rtl_file, machine_t *machine) {

    /* current statement: */
    statement_t *statement;

    /* current state structure */
    state_t *st = NULL;

    /* current state index */
    int state = -1;

    /* next state value */
    int next_state;

    /* line counter: */
    int line_index = 0;

    /* loop counter */
    int i;

    /* read statements: */
    while (statement = next_statement(rtl_file, line_index)) {

        if (statement->type == STATEMENT_MICROINSTR) {

            /* increase the index: */
            state++;

            /* get state structure: */
            st = machine->states[state];

            /* let it refer to next state: */
            for (i = 0; i < (1<<machine->input_lines_count); i++)
                st->next_state[i] = state+1;

        } else if (statement->type == STATEMENT_IF) {

            /* get next state */
            next_state = symbol_to_state(machine, statement->tokens[4]);

            /* unknown reference? */
            if (next_state == -1) {
                fprintf(stderr, "Error in line %d: ", line_index+1);
                fprintf(stderr, "Unsolvable reference.\n");
                free_statement(statement);
                return -6;
            }

            /* if condition before any microinstruction? */
            if (state == -1) {
                fprintf(stderr, "Error in line %d: ", line_index+1);
                fprintf(stderr, "Cannot begin with an 'If' or 'Goto'.\n");
                free_statement(statement);
                return -7;
            }

            /* evaluate condition */
            if (evaluate_cond(st, next_state, statement->tokens[1],
                              statement->tokens[2]) == -1) {
                fprintf(stderr, "Error in line %d: ", line_index+1);
                fprintf(stderr, "Uknown signal or value.\n");
                free_statement(statement);
                return -8;
            }

        }

        /* done: */
        free_statement(statement);

        /* this is useful when printing errors to stderr: */
        line_index++;

    }

    /* no error */
    return 0;
}

/****************************************************************************/
/*                              translate()                                 */
/****************************************************************************/

int translate(FILE *rtl_file, FILE *rom_file) {

    /* return value */
    int ret;

    /* the ROM word being written */
    int word;

    /* loop counters */
    int i, j, k;

    /* allocate a machine structure: */
    machine_t *machine = alloc_machine();

    /* do pass1 */
    if (ret = pass1(rtl_file, machine))
        return ret;

    /* re-read the RTL file from beginning */
    fseek(rtl_file, 0, SEEK_SET);

    /* read the file again: */
    if (ret = pass2(rtl_file, machine)) {
        return ret;
    }

    /* now write the binary file */
    for (i = 0; i < machine->states_count; i++) {
        /* every state has multiple cases according to input lines */
        for (j = 0; j < (1<<machine->input_lines_count); j++) {
            word = 0;
            /* control lines */
            for (k = 0; k < machine->control_lines_count; k++)
                word |= machine->states[i]->output[k]<<k;
            /* next state */
            word |= machine->states[i]->next_state[j]<<k;
            /* write the word to binary file */
            fwrite(&word, ROM_WORD_SIZE/8, 1, rom_file);
        }
    }

    /* output crticial information */
    printf("Control lines: %d\n", machine->control_lines_count);
    printf("Input lines:   %d\n", machine->input_lines_count);
    printf("State count:   %d\n", machine->states_count);

    /* deallocate machine structure */
    free_machine(machine);

    /* done */
    return 0;
}

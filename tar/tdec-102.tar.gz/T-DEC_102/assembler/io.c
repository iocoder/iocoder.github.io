/* File I/O Layer */

#include <stdio.h>
#include <stdlib.h>

#include "linkedlist.h"
#include "asm.h"

/****************************************************************************/
/*                             open_file()                                  */
/****************************************************************************/

int open_file(file_t *file, char *name, char *mode) {

    /* try to open the file */
    if (!(file->fd = fopen(name, mode)))
        return -1; /* error */

    /* initialize the file structure */
    file->name = STRCPY(name);
    file->mode = STRCPY(mode);
    file->cur_line = 0;

    /* done */
    return 0;

}

/****************************************************************************/
/*                            reopen_file()                                 */
/****************************************************************************/

int reopen_file(file_t *file) {

    /* the new FILE structure */
    FILE *newfd;

    /* try to reopen the file */
    if (!(newfd = fopen(file->name, file->mode)))
        return -1; /* error */

    /* close the old file */
    fclose(file->fd);
    file->fd = newfd;

    /* re-initialize the file structure */
    file->cur_line = 0;

    /* done */
    return 0;

}

/****************************************************************************/
/*                             close_file()                                 */
/****************************************************************************/

void close_file(file_t *file) {

    fclose(file->fd);
    free(file->name);
    free(file->mode);

}

/****************************************************************************/
/*                              strsplit()                                  */
/****************************************************************************/

void strsplit(char *str, char *del, linkedlist *ret) {

    char *brk;
    char *tok;
    int len;

    linkedlist_init(ret);

    while(*str) {

        /* find first special character */
        brk = strpbrk(str, del);

        /* get len of current token */
        if (brk == NULL) {
            len = strlen(str);
        } else if (brk == str) {
            len = 1;
        } else {
            len = brk-str;
        }

        /* tokenize */
        tok = malloc(len+1);
        strncpy(tok, str, len);
        tok[len] = 0;

        /* add token to the list */
        linkedlist_addLast(ret, tok);

        /* update string pointer */
        str += len;

    }

}

/****************************************************************************/
/*                              get_line()                                  */
/****************************************************************************/

int get_line(file_t *asm_file, linkedlist *line) {

    /* buffer to read the line: */
    char buf[MAX_LINE_SIZE+1];

    /* token variable */
    char *tok;

    /* loop counter */
    int i;

    /* initialize the linked list */
    linkedlist_init(line);

    /* read next line */
    if (fgets(buf, MAX_LINE_SIZE, asm_file->fd) == NULL) {
        /* End of File */
        return 0;
    }

    /* tokenize the line */
    tok = strtok(buf, " \t\n\r");

    /* read tokens */
    while(tok && tok[0] != '#') {
        /* split the token by special characters */
        linkedlist sub;
        strsplit(tok, "[:],", &sub);

        /* move them all to the big linked list */
        for (i = 0; i < linkedlist_size(&sub); i++)
            linkedlist_addLast(line, linkedlist_get(&sub, i));

        /* clear "sub" linked list */
        linkedlist_clear(&sub);

        /* next token */
        tok = strtok(NULL, " \t\n\r");
    }

    /* update line counter */
    asm_file->cur_line++;

    /* done */
    return 1;

}

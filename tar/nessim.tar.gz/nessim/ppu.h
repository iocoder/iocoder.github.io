#ifndef NESSIM_PPU_H
#define NESSIM_PPU_H

void ppu_clk();

#endif

#ifndef JOYPAD_H
#define JOYPAD_H

#include <SDL/SDL.h>

unsigned char joypad0_read();
unsigned char joypad1_read();
void joypad_write(unsigned char data);
void keydown(SDL_Event e);
void keyup(SDL_Event e);

#endif


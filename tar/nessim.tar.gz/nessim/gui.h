#ifndef NESSIM_GUI_H
#define NESSIM_GUI_H

#include <SDL/SDL.h>

/* GUI elements */
SDL_Surface* screen;

#endif


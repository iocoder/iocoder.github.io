#ifndef __MICROASM_H
#define __MICROASM_H

#include <stdio.h>

#define STATEMENT_LABEL         0
#define STATEMENT_MICROINSTR    1
#define STATEMENT_GOTO          2
#define STATEMENT_IF            3
#define STATEMENT_EMPTY         4
#define STATEMENT_ERROR         5

#define MAX_LINE_SIZE           4096

#define ROM_WORD_SIZE           32

typedef struct statement {
    int type;
    char **tokens;
    int tokens_count;
} statement_t;

typedef struct symbol {
    struct symbol *next;
    char *label;
    int state;
} symbol_t;

typedef struct state {
   char *output;
   int  *next_state;
} state_t;

typedef struct machine {
    /* output signals: */
    const char **control_lines;
    int control_lines_count;

    /* input signals: */
    const char **input_lines;
    int input_lines_count;

    /* states: */
    state_t **states;
    int states_count;
    int max_states;

    /* symbol table: */
    symbol_t *symhead;

} machine_t;

/* external variables: */
extern const char *control_lines[];
extern const char *input_lines[];

/* prototypes: */
state_t *alloc_state(machine_t *machine);
void free_state(state_t *state);
machine_t *alloc_machine();
void add_symbol(machine_t *machine, char *label, int state);
int symbol_to_state(machine_t *machine, char *label);
void free_machine(machine_t *machine);
statement_t *alloc_statement();
void free_statement(statement_t *statement);
int translate(FILE *rtl_file, FILE *rom_file);
state_t *rtl_to_signals(machine_t *machine, statement_t *statement);
int evaluate_cond(state_t *state, int next_state, char *name, char *value);

#endif

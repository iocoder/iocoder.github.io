#include <stdio.h>
#include <SDL/SDL.h>

#include "clock.h"
#include "vga.h"
#include "cpu.h"
#include "kbd.h"

SDL_Surface* screen = NULL;

int main(int argc, char *argv[]) {

    int err;
    pthread_t ct[10];
    int args = 0;

    /* check the arguments */
    if (argc != 4) {
        fprintf(stderr, "Invalid arguments. Usage: ");
        fprintf(stderr, "%s <microcode> <cpulookup> <firmware>\n", argv[0]);
        return -1;
    }

    /* print splash */
    printf("*********************************\n");
    printf("*  6502 FPGA COMPUTER EMULATOR  *\n");
    printf("*********************************\n");
    printf("\n");

    /* loading... */
    printf("The emulator is loading...\n");

    /* initialize SDL */
    SDL_Init(SDL_INIT_EVERYTHING);

    /* Set up screen */
    screen = SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE);

    /* Set title */
    SDL_WM_SetCaption("6502 FPGA Computer Emulator", NULL);

    /* initialize CPU */
    cpu_init(argv[1], argv[2]);

    /* initialize memory */
    mem_init(argv[3]);

    /* initialize VGA */
    vga_init();

    /* initialize keyboard */
    kbd_init();

    /* run clock */
    clock_handler();

    /* quit SDL */
    SDL_Quit();

    /* done */
    return 0;

}

/* clock handler */

#include <SDL/SDL.h>
#include <sys/times.h>
#include <stdio.h>
#include <stdlib.h>

#include "joypad.h"

int tick = 0;

__extension__ typedef long long int nes_int64_t;
struct timeval start, end;
nes_int64_t next_refresh = 8;

nes_int64_t elapsed() {

    nes_int64_t mtime, seconds, useconds;

    gettimeofday(&end, NULL);

    if (end.tv_sec < start.tv_sec) {
        seconds = 60 - start.tv_sec + end.tv_sec;
    } else {
        seconds  = end.tv_sec - start.tv_sec;
    }
    if (end.tv_usec < start.tv_usec) {
        useconds = 1000 - start.tv_usec + end.tv_usec;
    } else {
        useconds = end.tv_usec - start.tv_usec;
    }

    mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
    return mtime;

}

int watch_events() {
    /* handle events */
    SDL_Event e;
    while (SDL_PollEvent(&e) != 0) {
        if (e.type == SDL_QUIT) {
            return 1;
        } else if (e.type == SDL_KEYDOWN) {
            keydown(e);
        } else if (e.type == SDL_KEYUP) {
            keyup(e);
        }
    }
    return 0;
}

void clock_handler() {
    while(1) {
        int i = 0;
        extern unsigned char HIT;
        while (elapsed() < next_refresh) {
            cpu_cycle();
            i++;
            if (i == 1000)
                HIT = 1;
        }
        if (watch_events()) {
            extern int done;
            while (!done);
            return;
        }
        next_refresh = elapsed()+20;
        ppu_clk();
        tick++;
    }
}

void clock_init() {
    /* calculate start time */
    gettimeofday(&start, NULL);
}

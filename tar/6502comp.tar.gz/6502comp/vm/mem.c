#include <stdio.h>
#include <stdlib.h>

#include "mem.h"
#include "kbd.h"
#include "vga.h"

unsigned char ram[0x8000];
unsigned char rom[0x8000];

void dump_mem() {
    FILE *f = fopen("mem.img", "w");
    fwrite(ram, sizeof(ram), 1, f);
    fwrite(rom, sizeof(rom), 1, f);
    fclose(f);
    system("konsole -e hexedit mem.img");
}

unsigned char mem_read(unsigned short addr) {

    if (addr < 0x4000) {
        return ram[addr & 0x7FFF];
    } else if (addr < 0x6000) {
        return kbd_read(addr);
    } else if (addr < 0x8000) {
        return ram[addr & 0x7FFF];
    } else {
        return rom[addr & 0x7FFF];
    }

}

void mem_write(unsigned short addr, unsigned char data) {

    if (addr < 0x4000) {
        ram[addr & 0x7FFF] = data;
    } else if (addr < 0x6000) {
        kbd_write(addr, data);
    } else if (addr < 0x8000) {
        vga_write(addr, ram[addr & 0x7FFF] = data);
    }

}

void mem_init(char *firmware_name) {

    FILE *f;
    int i;

    /* load the operating system */
    if (!(f = fopen(firmware_name, "r"))) {
        fprintf(stderr, "Error: cannot open %s.\n", firmware_name);
        exit(-2);
    }
    fread(rom, sizeof(rom), 1, f);
    fclose(f);

    /* fill the RAM with garbage */
    for (i = 0; i < sizeof(ram); i++)
        ram[i] = i;

}

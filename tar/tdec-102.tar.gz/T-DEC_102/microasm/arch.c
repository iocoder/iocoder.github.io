
/* T-DEC/102-specific code */

#include <stdlib.h>
#include <string.h>
#include "microasm.h"

#define OP1(X) (!strcmp(operand1, X))
#define OP2(X) (!strcmp(operand2, X))

/* control lines: */
const char *control_lines[] = {

    "PC0Read",
    "PC1Read",
    "PC0Write",
    "PC1Write",
    "PCAdd",

    "IR0Write",
    "IR1Write",
    "IR2Read",
    "IR2Write",
    "IR3Read",
    "IR3Write",

    "MAR0Write",
    "MAR1Write",
    "MEMR",
    "MEMW",

    "ALU0Write",
    "ALU1Write",
    "ALU2Read",

    "REGRead",
    "REGWrite",
    "REGASel",
    "REGBSel",
    "REGCSel",
    "REGSel",

    NULL
};

/* input lines: */
const char *input_lines[] = {
    "Opcode0",
    "Opcode1",
    "Opcode2",
    "Opcode3",

    "EvalCond",

    NULL
};

int signal_to_index(char *signal) {
    int i = 0;
    while(control_lines[i] && strcmp(control_lines[i], signal)) i++;
    if (!control_lines[i]) {
        fprintf(stderr,"BUG! Cannot find the control line named %s\n",signal);
    }
    return i;
}

state_t *rtl_to_signals(machine_t *machine, statement_t *statement) {

    /* declare operands: */
    char *operand1, *operand2;

    /* declare the state pointer: */
    state_t *state;

    /* read operands: */
    operand1 = statement->tokens[0];
    operand2 = statement->tokens[1];

    /* allocate a new state: */
    state = alloc_state(machine);

    /* special case: */
    if (OP1("[PC]") && OP2("[PC]+1")) {
        /* increase PC */
        /* state->output[signal_to_index("PC0Write")] = 1;
           state->output[signal_to_index("PC1Write")] = 1; */
        state->output[signal_to_index("PCAdd")] = 1;
        return state;
    }

    /* left operand (WRITE):
     * things that can be written to are:
     * PC0, PC1, IR0, IR1, IR2, IR3, MAR0, MAR1
     * [[MAR]], ALU0, ALU1, REGA, REGB, and REGC.
     */
    if (OP1("[PC0]")) {
        state->output[signal_to_index("PC0Write")] = 1;
    } else if (OP1("[PC1]")) {
        state->output[signal_to_index("PC1Write")] = 1;
    } else if (OP1("[IR0]")) {
        state->output[signal_to_index("IR0Write")] = 1;
    } else if (OP1("[IR1]")) {
        state->output[signal_to_index("IR1Write")] = 1;
    } else if (OP1("[IR2]")) {
        state->output[signal_to_index("IR2Write")] = 1;
    } else if (OP1("[IR3]")) {
        state->output[signal_to_index("IR3Write")] = 1;
    } else if (OP1("[MAR0]")) {
        state->output[signal_to_index("MAR0Write")] = 1;
    } else if (OP1("[MAR1]")) {
        state->output[signal_to_index("MAR1Write")] = 1;
    } else if (OP1("[[MAR]]")) {
        state->output[signal_to_index("MEMW")] = 1;
    } else if (OP1("[ALU0]")) {
        state->output[signal_to_index("ALU0Write")] = 1;
    } else if (OP1("[ALU1]")) {
        state->output[signal_to_index("ALU1Write")] = 1;
    } else if (OP1("[RSEL]")) {
        state->output[signal_to_index("REGSel")] = 1;
    } else if (OP1("[REG]")) {
        state->output[signal_to_index("REGWrite")] = 1;
    } else if (OP1("[NONE]")) {

    } else {
        /* invalid operand */
        free_state(state);
        return NULL;
    }

    /* right operand (READ):
     * things that can be read from are:
     * PC0, PC1, IR2, IR3, [[MAR]],
     * ALU2, REGA, REGB, and REGC.
     */
    if (OP2("[PC0]")) {
        state->output[signal_to_index("PC0Read")] = 1;
    } else if (OP2("[PC1]")) {
        state->output[signal_to_index("PC1Read")] = 1;
    } else if (OP2("[IR2]")) {
        state->output[signal_to_index("IR2Read")] = 1;
    } else if (OP2("[IR3]")) {
        state->output[signal_to_index("IR3Read")] = 1;
    } else if (OP2("[[MAR]]")) {
        state->output[signal_to_index("MEMR")] = 1;
    } else if (OP2("[ALU2]")) {
        state->output[signal_to_index("ALU2Read")] = 1;
    } else if (OP2("[REGA]")) {
        state->output[signal_to_index("REGASel")] = 1;
    } else if (OP2("[REGB]")) {
        state->output[signal_to_index("REGBSel")] = 1;
    } else if (OP2("[REGC]")) {
        state->output[signal_to_index("REGCSel")] = 1;
    } else if (OP2("[REG]")) {
        state->output[signal_to_index("REGRead")] = 1;
    } else if (OP2("[NONE]")) {

    } else {
        /* invalid operand */
        free_state(state);
        return NULL;
    }

    /* done: */
    return state;

}

int evaluate_cond(state_t *state, int next_state, char *name, char *value) {

    /* loop counters */
    int i, j;

    /* construct input line values array */
    char vals[sizeof(input_lines)/sizeof(char *)-1];

    /* read values: */
    if (!strcmp(name, "Opcode") && strlen(value) == 4) {
        vals[0] = value[3];
        vals[1] = value[2];
        vals[2] = value[1];
        vals[3] = value[0];
        vals[4] = 'x';
    } else if (!strcmp(name, "EvalCond") && strlen(value) == 1) {
        vals[0] = 'x';
        vals[1] = 'x';
        vals[2] = 'x';
        vals[3] = 'x';
        vals[4] = value[0];
    } else if (!strcmp(name, "")) {
        vals[0] = 'x';
        vals[1] = 'x';
        vals[2] = 'x';
        vals[3] = 'x';
        vals[4] = 'x';
    } else {
        /* unknown signal name or value */
        return -1;
    }

    /* now generate all possible cases and evaluate matching cases: */
    for (i = 0; i < (1<<sizeof(vals)); i++) {
        /* is this case matching? */
        for(j = 0; j < sizeof(vals); j++)
            if (vals[j] != 'x' && (vals[j]-'0') != ((i>>j)&1))
                break;

        /* if matching, set next_state of this case */
        if (j == sizeof(vals)) {
            state->next_state[i] = next_state;
        }
    }

    /* done */
    return 0;

}

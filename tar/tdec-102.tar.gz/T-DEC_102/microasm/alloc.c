
/* data structure allocation and deallocation. */

#include <stdlib.h>
#include <string.h>
#include "microasm.h"

/****************************************************************************/
/*                            alloc_state()                                 */
/****************************************************************************/

state_t *alloc_state(machine_t *machine) {

    /* declare counter: */
    int i;

    /* allocate memory: */
    state_t *st = malloc(sizeof(state_t));

    /* output signals: */
    st->output = malloc(machine->control_lines_count*sizeof(char));
    for (i = 0; i < machine->control_lines_count; i++)
        st->output[i] = 0;

    /* next state: */
    st->next_state = malloc((1<<machine->input_lines_count)*sizeof(int));
    for (i = 0; i < (1<<machine->input_lines_count); i++)
        st->next_state[i] = -1;

    /* done: */
    return st;
}

/****************************************************************************/
/*                            free_state()                                  */
/****************************************************************************/

void free_state(state_t *state) {
    free(state->output);
    free(state->next_state);
    free(state);
}

/****************************************************************************/
/*                            alloc_machine()                               */
/****************************************************************************/

machine_t *alloc_machine() {

    /* allocate machine structure: */
    machine_t *machine = malloc(sizeof(machine_t));

    /* fetch control lines: */
    machine->control_lines = control_lines;
    machine->control_lines_count = 0;
    while (machine->control_lines[machine->control_lines_count])
        machine->control_lines_count++;

    /* fetch input lines: */
    machine->input_lines  = input_lines;
    machine->input_lines_count = 0;
    while (machine->input_lines[machine->input_lines_count])
        machine->input_lines_count++;

    /* allocate state array: */
    machine->max_states = 1<<(ROM_WORD_SIZE-machine->control_lines_count);
    machine->states = malloc(machine->max_states*sizeof(state_t *));
    machine->states_count = 0;

    /* symbol table */
    machine->symhead = NULL;

    /* done: */
    return machine;
}

/****************************************************************************/
/*                              add_symbol()                                */
/****************************************************************************/

void add_symbol(machine_t *machine, char *label, int state) {

    /* a temporary variable that holds a copy of label */
    char *tmp;

    /* symbol structure */
    symbol_t *symbol;

    /* allocate a copy of label */
    tmp = malloc(strlen(label) + 1);

    /* copy label string */
    strcpy(tmp, label);

    /* allocate symbol structure */
    symbol = malloc(sizeof(symbol_t));

    /* set the values of symbol */
    symbol->next = machine->symhead;
    symbol->label = tmp;
    symbol->state = state;

    /* insert into linked list */
    machine->symhead = symbol;

}

/****************************************************************************/
/*                            symbol_to_state()                             */
/****************************************************************************/

int symbol_to_state(machine_t *machine, char *label) {

    /* symbol pointer */
    symbol_t *p = machine->symhead;

    /* loop on all symbols */
    while(p && strcmp(label, p->label))
        p = p->next;

    /* return the found state structure */
    if (!p || p->state >= machine->states_count)
        return -1;
    return p->state;

}

/****************************************************************************/
/*                            free_machine()                                */
/****************************************************************************/

void free_machine(machine_t *machine) {
    /* TODO */
}

/****************************************************************************/
/*                          alloc_statement()                               */
/****************************************************************************/

statement_t *alloc_statement() {

    statement_t *statement = malloc(sizeof(statement_t));
    statement->tokens = NULL;
    statement->tokens_count = 0;
    return statement;

}

/****************************************************************************/
/*                           free_statement()                               */
/****************************************************************************/

void free_statement(statement_t *statement) {

    int i;
    if (statement->tokens) {
        for (i = 0; i < statement->tokens_count; i++)
            free(statement->tokens[i]);
        free(statement->tokens);
    }
    free(statement);

}

/* Assembler Main File */

#include <stdio.h>
#include <stdlib.h>

#include "asm.h"

int main(int argc, char *argv[]) {

    /* streams: */
    file_t *files;

    /* job structure: */
    job_t job;

    /* loop counters: */
    int i, j;

    /* current instruction being written */
    instruct_t *instr;

    /* return value: */
    int err;

    /* make sure argument count is valid */
    if (argc < 3) {
        fprintf(stderr, "USAGE: %s (asm_file's) bin_file\n", argv[0]);
        return -1;
    }

    /* allocate memory for array of file structures */
    files = malloc(sizeof(file_t)*(argc-1));

    /* open all the files: */
    for (i = 1; i < argc; i++) {
        if (err = open_file(&files[i-1], argv[i], i==(argc-1)?"w" :"r")) {
            /* failed to open the file */
            fprintf(stderr, "Can't open %s!\n", argv[i]);
            for (j = 0; j < i-1; j++)
                close_file(&files[j]);
            return err;
        }
    }

    /* construct the job structure */
    job.files = files;
    linkedlist_init(&(job.instructs));
    linkedlist_init(&(job.symbols));
    job.fcount = argc-1;
    job.binsize = 0;
    job.regs = regs;
    job.isa = isa;

    /* pass1: read assembly files and store symbols: */
    if (err = do_pass1(&job)) {
        /* close all streams */
        for (i = 0; i < argc-1; i++)
            close_file(&files[i]);
        return err;
    }

    /* pass2: generate binary code and resolve references */
    if (err = do_pass2(&job)) {
        /* close all streams */
        for (i = 0; i < argc-1; i++)
            close_file(&files[i]);
        return err;
    }

    /* write out the binary code */
    for (i = 0; i < linkedlist_size(&(job.instructs)); i++) {
        instr = linkedlist_get(&(job.instructs), i);
        for (j = 0; j < instr->size; j++)
            fprintf(files[argc-2].fd, "%c", instr->bytes[j]);
    }

    /* close all streams */
    for (i = 0; i < argc-1; i++)
        close_file(&files[i]);

    /* done */
    return 0;

}

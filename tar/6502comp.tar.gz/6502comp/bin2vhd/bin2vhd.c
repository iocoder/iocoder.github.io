#include <stdio.h>

int main(int argc, char *argv[]) {

    /* convert argv[1] it into VHDL array */

    FILE *f;
    int i = 0;
    int eof = 0;
    unsigned int word = 0;
    int wordsize;
    int words;

    if (argc != 6) {
        fprintf(stderr, "Your arguments are invalid.\n");
        return -1;
    }

    if (!(f = fopen(argv[1], "r"))) {
        fprintf(stderr, "Cannot open the file!\n");
        return -2;
    }

    wordsize = atoi(argv[2]);
    words = atoi(argv[3]);

    printf("library IEEE;\n");
    printf("use IEEE.STD_LOGIC_1164.ALL;\n");
    printf("use IEEE.STD_LOGIC_ARITH.ALL;\n");
    printf("use IEEE.STD_LOGIC_UNSIGNED.ALL;\n");
    printf("\n");
    printf("package %s is", argv[4]);
    printf("\n\n");
    printf("type %s_t is array (0 to %d) ", argv[5], words-1);
    printf("of STD_LOGIC_VECTOR (%d downto 0);\n", wordsize*8-1);
    printf("constant %s : %s_t := (\n", argv[5], argv[5]);

    for (i = 0; i < words; i++) {

        if (!eof && !fread(&word, wordsize, 1, f)) {
            eof = 1;
            word = 0;
        }

        if (!(i%0x10)) {
            printf("\n");
            printf("-- row 0x%0*X", wordsize*2-1, i/0x10);
            printf("\n");
        }

        printf("x\"%0*X\"", wordsize*2, word);

        if ((i+1)%0x08) {
            printf(", ");
        } else {
            if (i < words-1)
                printf(",");
            printf("\n");
        }

    }

    printf("\n);\n\nend package;\n");

    return 0;

}

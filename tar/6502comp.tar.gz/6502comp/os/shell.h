#ifndef _6502COMP_SHELL_H
#define _6502COMP_SHELL_H

void shell();

#endif


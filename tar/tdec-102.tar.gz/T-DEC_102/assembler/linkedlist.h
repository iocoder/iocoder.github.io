/* Singly Linked List Header File */

#ifndef _LINKEDLIST_H
#define _LINKEDLIST_H

#include <stdbool.h>

typedef struct SNode_s {
	struct SNode_s *next; /* pointer to next node in the list. */
	void   *val;          /* the value stored by this node. */
} SNode;

typedef struct {
	SNode *head;
	int size;
} linkedlist;

/* Prototypes: */
void  linkedlist_init(linkedlist *);
void  linkedlist_add(linkedlist *, int, void *);
void  linkedlist_addLast(linkedlist *, void *);
void *linkedlist_get(linkedlist *, int);
void  linkedlist_set(linkedlist *, int, void *);
void  linkedlist_clear(linkedlist *);
bool  linkedlist_isEmpty(linkedlist *);
void  linkedlist_remove(linkedlist *, int);
int   linkedlist_size(linkedlist *);
linkedlist linkedlist_sublist(linkedlist *, int, int);
bool  linkedlist_contains(linkedlist *, void *);
void  linkedlist_print(linkedlist *);

#endif

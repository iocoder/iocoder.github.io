#ifndef VM_MEM_H
#define VM_MEM_H

void dump_mem();
unsigned char mem_read(unsigned short addr);
void mem_write(unsigned short addr, unsigned char data);
void mem_init(char *firmware_name);

#endif

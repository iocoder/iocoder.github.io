/* first pass */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "linkedlist.h"
#include "asm.h"

int get_instr_size(job_t *job, instruct_t *instruct) {

    int size = 0;
    int i = instruct->i_op;
    while(job->isa[i++]);
    while(job->isa[i++])
        size += atoi(strchr(job->isa[i-1], ':') + 1);
    return size/8;

}

int tokcmp(job_t *job, char *code, char *arch) {

    /* return 0 if equivalent */
    int i;

    if (!arch)
        return -1;

    if (!strcmp(arch, "NUM")) {
        /* code should be a valid number or reference */

        if (code[0] == '^' || code[0] == '~')
            code++;

        /* test hexadecimal */
        if (strlen(code) > 2 && code[0] == '0' &&
            (code[1] == 'x' || code[1] == 'X')) {

            for (i = 2; i < strlen(code); i++) {
                if (!((code[i] >= '0' && code[i] <= '9') ||
                      (code[i] >= 'A' && code[i] <= 'F') ||
                      (code[i] >= 'a' && code[i] <= 'f')))
                    return -1; /* not a valid hexadecimal number */
            }

            return 0;

        }

        /* test decimal */
        if (code[0] >= '0' && code[0] <= '9') {
            for (i = 2; i < strlen(code); i++)
                if (!(code[i] >= '0' && code[i] <= '9'))
                    return -1; /* not a valid decimal number */
            return 0;
        }

        /* now it seems it is a reference. */
        for (i = 0; job->regs[i]; i++)
            if (!strcmp(job->regs[i], code))
                return -1; /* not a valid reference */

        return 0;

    } else if (!strcmp(arch, "REG")) {

        /* register */
        for (i = 0; job->regs[i]; i++)
            if (!strcmp(job->regs[i], code))
                return 0;

        return -1;

    } else {
        /* [ , : ] and instruction mnemonics */
        return strcmp(code, arch); /* do literal comparison */
    }

}

int lookop(job_t *job, linkedlist *stmnt) {

    /* look up for the matching op */

    int i;
    char **ops = job->isa;

    while (*ops) {

        for (i = 0; i < linkedlist_size(stmnt) &&
                    !tokcmp(job, linkedlist_get(stmnt, i), ops[i]); i++);
        if (i == linkedlist_size(stmnt) && !ops[i]) {
            /* we've found what we've been looking for */
            return ops-job->isa;
        }
        /* loop till reach next opcode descriptor */
        while(*ops)
            ops++;
        ops++;
        while(*ops)
            ops++;
        ops++;
    }

    return -1;
}

int do_pass1(job_t *job) {

    linkedlist curline;
    int i, j, k;
    instruct_t *instruct;

    /* loop on all assembly files */
    for (i = 0; i < job->fcount-1; i++) {
        while(get_line(&(job->files[i]), &curline)) {

            /* if a label exists, store it */
            if (linkedlist_size(&curline) >= 2 &&
                *((char *)linkedlist_get(&curline, 1)) == ':') {
                /* there is a label on this line */
                symbol_t *symbol = malloc(sizeof(symbol_t));
                symbol->symname = linkedlist_get(&curline, 0);
                symbol->address = job->binsize;
                linkedlist_addLast(&(job->symbols), symbol);
                linkedlist_remove(&curline, 0);
                linkedlist_remove(&curline, 0);
            }

            /* if an instruction exists, read it */
            if (linkedlist_size(&curline)) {

                /* allocate memory for instruct structure */
                instruct = malloc(sizeof(instruct_t));

#if 0
                /* one line has been tokenized */
                for (j = 0; j < linkedlist_size(&curline); j++) {
                    printf("%s ", linkedlist_get(&curline, j));
                }
                printf("\n");
#endif

                /* we need to find the matching instruction opcode */
                if ((instruct->i_op = lookop(job, &curline)) == -1) {
                    fprintf(stderr, "Error: Unknown instruction or ");
                    fprintf(stderr, "operands (%s:%d).\n",
                                    job->files[i].name,
                                    job->files[i].cur_line);
                    while (linkedlist_size(&curline)) {
                        free(linkedlist_get(&curline, 0));
                        linkedlist_remove(&curline, 0);
                    }
                    free(instruct);
                    return -1;
                }

                /* set values of instruct */
                instruct->tokens = curline;
                instruct->file = &(job->files[i]);
                instruct->line = job->files[i].cur_line;
                instruct->size = get_instr_size(job, instruct);

                /* prepare machine code bytes */
                instruct->bytes = malloc(instruct->size * sizeof(int));
                for (j = 0; j < instruct->size; j++)
                    instruct->bytes[j] = 0;

                /* add to instruction set */
                linkedlist_addLast(&(job->instructs), instruct);

                /* increase binary size */
                job->binsize += instruct->size;

            }

        }
    }

    /* done */
    return 0;
}

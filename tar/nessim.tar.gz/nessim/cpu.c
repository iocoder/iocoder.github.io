#include <stdio.h>
#include <stdlib.h>

#include "mem.h"

typedef struct instr {
    char *mnemonic;
    void (*func)();
    unsigned char opcodes[13];
    unsigned char mem;
} instr_t;

typedef struct {
    instr_t *instr;
    int mode;
} opcode_t;

opcode_t opcodes[256] = {0};

int nmi_pulse = 0; /* NMI */
int irq_pulse = 0; /* IRQ */

unsigned char test_mem[0x10000];
unsigned char testing = 0;
unsigned char test_hlt = 0;
unsigned char printing = 0;

/*****************************************************************************/
/*                               REGISTERS                                   */
/*****************************************************************************/

/* architectural registers */
unsigned char a = 0;
unsigned char y = 0;
unsigned char x = 0;
unsigned char pcl = 0;
unsigned char pch = 0;
unsigned char s = 0xFD;
unsigned char p = 0x34; /* status reg */

/* internal registers */
unsigned char ir  = 0;
unsigned char abl = 0; /* memory address low */
unsigned char abh = 0; /* memory address high */
unsigned char dl  = 0; /* input data latch */
unsigned char dbb = 0; /* data bus buffer */
unsigned char alu = 0; /* alu internal accumulator */
void (*seq)() = NULL; /* sequencer */

void set_c(unsigned char val) {
    p = (p & (~0x01)) | (val?0x01:0);
}

void set_z(unsigned char val) {
    p = (p & (~0x02)) | (val?0x02:0);
}

void set_i(unsigned char val) {
    p = (p & (~0x04)) | (val?0x04:0);
}

void set_d(unsigned char val) {
    p = (p & (~0x08)) | (val?0x08:0);
}

void set_b(unsigned char val) {
    p = (p & (~0x10)) | (val?0x10:0);
}

void set_v(unsigned char val) {
    p = (p & (~0x40)) | (val?0x40:0);
}

void set_n(unsigned char val) {
    p = (p & (~0x80)) | (val?0x80:0);
}

int get_c() {
    return (p & 0x01) ? 1 : 0;
}

int get_z() {
    return (p & 0x02) ? 1 : 0;
}

int get_i() {
    return (p & 0x04) ? 1 : 0;
}

int get_d() {
    return (p & 0x08) ? 1 : 0;
}

int get_b() {
    return (p & 0x10) ? 1 : 0;
}

int get_v() {
    return (p & 0x40) ? 1 : 0;
}

int get_n() {
    return (p & 0x80) ? 1 : 0;
}


/*****************************************************************************/
/*                  ADDRESSING MODES AND MEMORY INTERFACE                    */
/*****************************************************************************/

#define IMMEDIATE       0
#define ABSOLUTE        1
#define ZEROPAGE        2
#define ACCUM           3
#define IMPLIED         4
#define INDX_INDIR      5
#define INDIR_INDX      6
#define INDX_ZERO_X     7
#define INDX_ABS_X      8
#define INDX_ABS_Y      9
#define RELATIVE        10
#define ABS_INDIR       11
#define INDX_ZERO_Y     12

char *modes[] = {
    "imm",
    "abs",
    "zp",
    "acc",
    "impl",
    "(zp,x)",
    "(zp),y",
    "zp,x",
    "abs,x",
    "abs,y",
    "rel",
    "(abs)",
    "zp,y"
};

unsigned char mread() {
    if (testing)
        return test_mem[(abh<<8) | abl];
    return cpu_mem_read((abh<<8) | abl);
}

void mwrite(unsigned char val) {
    if (testing)
        test_mem[(abh<<8) | abl] = val;
    cpu_mem_write((abh<<8) | abl, val);
}


unsigned char fetch_byte() {

    abl = pcl;
    abh = pch;
    pcl += 1;
    pch += (pcl == 0);
    return mread();

}

unsigned short fetch_word() {

    unsigned char low  = fetch_byte();
    unsigned char high = fetch_byte();

    return (high << 8) | low;

}

void calc_eff_address() {

    unsigned short addr;

    switch (opcodes[ir].mode) {

        case IMMEDIATE:
            /* PC is the effective address */
            abl = pcl;
            abh = pch;
            pcl += 1;
            pch += (pcl == 0);
            break;

        case ABSOLUTE:
            addr = fetch_word();
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case ZEROPAGE:
            abl = fetch_byte();
            abh = 0;
            break;

        case ACCUM:
            /* the source is the accumulator */
            break;

        case IMPLIED:
            /* should be handled differently */
            break;

        case INDX_INDIR:
            abl = fetch_byte() + x;
            abh = 0;
            addr = mread();
            abl++;
            addr |= mread()<<8;
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case INDIR_INDX:
            abl = fetch_byte();
            abh = 0;
            addr = mread();
            abl++;
            addr |= mread()<<8;
            addr += y; /* page boundary crossing happens here */
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case INDX_ZERO_X:
            abl = fetch_byte() + x;
            abh = 0;
            break;

        case INDX_ABS_X:
            addr = fetch_word() + x; /* page boundary crossing happens here */
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case INDX_ABS_Y:
            addr = fetch_word() + y; /* page boundary crossing happens here */
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case RELATIVE:
            addr = ((signed char) fetch_byte());
            addr += (pch<<8) | pcl;
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case ABS_INDIR:
            addr = fetch_word();
            abl = addr & 0xFF;
            abh = addr >> 8;
            addr = mread();
            abl++;
            abh += (abl == 0); /* page boundary crossing happens here */
            addr |= mread() << 8;
            abl = addr & 0xFF;
            abh = addr >> 8;
            break;

        case INDX_ZERO_Y:
            abl = fetch_byte() + y;
            abh = 0;
            break;

        default:
            break;

    }

}

unsigned char readM() {

    switch (opcodes[ir].mode) {

        case IMMEDIATE:
        case ABSOLUTE:
        case ZEROPAGE:
        case INDX_INDIR:
        case INDIR_INDX:
        case INDX_ZERO_X:
        case INDX_ABS_X:
        case INDX_ABS_Y:
        case ABS_INDIR:
        case INDX_ZERO_Y:
            return mread();

        case ACCUM:
            return a;

        case IMPLIED:
        case RELATIVE:
            fprintf(stderr, "BUG: 6502.c in readM()!\n");
            exit(-7);

        default:
            return 0;

    }

}

void writeM(unsigned char val) {

    switch (opcodes[ir].mode) {

        case ABSOLUTE:
        case ZEROPAGE:
        case INDX_INDIR:
        case INDIR_INDX:
        case INDX_ZERO_X:
        case INDX_ABS_X:
        case INDX_ABS_Y:
        case ABS_INDIR:
        case INDX_ZERO_Y:
            mwrite(val);
            break;

        case ACCUM:
            a = val;
            break;

        default:
            fprintf(stderr, "BUG: 6502.c in writeM()!\n");
            exit(-7);

    }

}

#if 0

void load_operand() {

    /* fetch bytes */
    switch (opcodes[ir].mode) {

        case IMMEDIATE:
            /* 1 cycle */
            abl = pcl;
            abh = pch;
            pcl += 1;
            pch += (pcl == 0);
            break;

        case ABSOLUTE:
            /* 3 cycles */
            abl = pcl;
            abh = pch;
            dl = dbb = mread();
            pcl += 1;
            pch += (pcl == 0);

            abl = pcl;
            abh = pch;
            dbb = mread();
            pcl += 1;
            pch += (pcl == 0);

            abl = dl;
            abh = dbb;
            break;

        case ZEROPAGE:
            /* 2 cycles */
            abl = pcl;
            abh = pch;
            dbb = mread();
            pcl += 1;
            pch += (pcl == 0);

            abl = dbb;
            abh = 0;
            break;

        case ACCUM:
            /* 1 cycle */
            dbb = a;
            break;

        case INDX_INDIR:
            /* 5 cycles */
            abl = pcl;
            abh = pch;
            alu = dbb = mread();
            pcl += 1;
            pch += (pcl == 0);

            alu += x;
            abl = alu;
            abh = 0;
            dl = dbb = mread(); /* lower byte of effective addr */

            alu += 1;
            abl = alu;
            dbb = mread(); /* higher byte of effective addr */

            abl = dl;

            dl = dbb;
            abh = dl;
            dbb = mread();
            break;

        case INDIR_INDX:
            /* 4 cycles (or 5 if page crossing) */
            abl = pcl;
            abh = pch;
            dl = dbb = mread();
            pcl += 1;
            pch += (pcl == 0);
            alu = 1;

            abl = dl;
            abh = 0;
            alu += dl;
            dl = dbb = mread(); /* dl = lower byte of (Indir) */

            abl = alu;
            dbb = mread(); /* db = higher byte */
            alu = dl;

            if (((unsigned short) alu)+y >= 0x100) {
                /* page crossing */
                alu += y;
                abl = alu;
                alu = dbb;

                alu += 1;
                abh = alu;
            } else {
                /* no page crossing */
                alu += y;
                abl = alu;
                abh = dbb;
            }
            dbb = mread();
            break;

        case INDX_ZERO_X:
            /* 3 cycles */
            abl = pcl;
            abh = pch;
            dbb = mread();
            pcl += 1;
            pch += (pcl == 0);
            alu = dbb;
            alu += x;
            abl = alu;
            abh = 0;
            dbb = mread();
            break;

        case INDX_ABS_X:
            /* 3 cycles */
            abl = pcl;
            abh = pch;
            alu = x;
            dbb = mread();
            dl  = ((unsigned short) alu) + dbb >= 0x100; /* carry */
            alu += dbb;
            pcl += 1;
            pch += (pcl == 0);

            abl = pcl;
            abh = pch;
            dbb = mread();
            pcl += 1;
            pch += (pcl == 0);
            abl = alu;

            alu = dl;
            alu += dbb;
            abh = alu;
            dbb = mread();
            break;


        case INDX_ABS_Y:
            /* 3 cycles */
            abl = pcl;
            abh = pch;
            alu = y;
            dbb = mread();
            dl  = ((unsigned short) alu) + dbb >= 0x100; /* carry */
            alu += dbb;
            pcl += 1;
            pch += (pcl == 0);

            abl = pcl;
            abh = pch;
            dbb = mread();
            pcl += 1;
            pch += (pcl == 0);
            abl = alu;

            alu = dl;
            alu += dbb;
            abh = alu;
            dbb = mread();
            break;

        case RELATIVE:
            break;

        case ABS_INDIR:
            break;

        case INDX_ZERO_Y:
            abl = pcl;
            abh = pch;
            dbb = mread();
            pcl += 1;
            pch += (pcl == 0);
            alu = dbb;
            alu += y;
            abl = alu;
            abh = 0;
            dbb = mread();
            break;

        default:
            break;

    }

}

#endif

/*****************************************************************************/
/*                            INSTRUCTION SET                                */
/*****************************************************************************/

void stub(int hlt) {
    printf("STUB at %02X%02X!!\n", pch, pcl);

    if (testing) {
        test_hlt = 1;
        return;
    }

    /* stop? */
    if (hlt == 1) {
        fprintf(stderr,"Cannot ignore this stub instruction.. exiting...\n");
        exit(-5);
    }

}

/* addition, and, arithmetic shift left */

void adc() {
    unsigned short res = a + readM() + get_c();
    a = res;
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
    set_c((res & 0x100) ? 1 : 0);
    if (((signed short) res) < -128 || ((signed short) res) > 127)
        set_v(1);
    else
        set_v(0);

}

void and() {
    a &= readM();
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
}

void asl() {
    unsigned char tmp = readM();
    set_c((tmp & 0x80) ? 1 : 0);
    tmp = tmp << 1;
    writeM(tmp);
    set_z(tmp == 0);
    set_n((tmp & 0x80) ? 1 : 0);
}

/* branching */

void bcc() {
    if (get_c() == 0) {
        pcl = abl;
        pch = abh;
    }
}

void bcs() {
    if (get_c() == 1) {
        pcl = abl;
        pch = abh;
    }
}

void beq() {
    if (get_z() == 1) {
        pcl = abl;
        pch = abh;
    }
}

void bit() {
    unsigned char m = readM();
    unsigned char res = m & a;
    set_z(res == 0);
    set_n((m & 0x80) ? 1 : 0);
    set_v((m & 0x40) ? 1 : 0);
}

void bmi() {
    if (get_n() == 1) {
        pcl = abl;
        pch = abh;
    }
}

void bne() {
    if (get_z() == 0) {
        pcl = abl;
        pch = abh;
    }
}

void bpl() {
    if (get_n() == 0) {
        pcl = abl;
        pch = abh;
    }
}

void brk() {
    stub(1);
    return;

    /* push pch */
    abl = s;
    abh = 1;
    mwrite(pch);
    s--;

    /* push pcl */
    abl = s;
    abh = 1;
    mwrite(pcl);
    s--;

    /* push p */
    abl = s;
    abh = 1;
    mwrite(p | 0x10); /* set B */
    s--;

    /* set interrupt flag */
    set_i(1);

    /* load PC with the interupt handler */
    abl = 0xFE;
    abh = 0xFF;
    pcl = dbb = mread();
    abl = 0xFF;
    pch = dbb = mread();

}

void bvc() {
    if (get_v() == 0) {
        pcl = abl;
        pch = abh;
    }
}

void bvs() {
    if (get_v() == 1) {
        pcl = abl;
        pch = abh;
    }
}

/* clear and compare */

void clc() {
    set_c(0);
}

void cld() {
    set_d(0);
}

void cli() {
    set_i(0);
}

void clv() {
    set_v(0);
}

void cmp() {
    unsigned char k = readM();
    unsigned char l = a;
    unsigned char m = l-k;
    set_c(l >= k ? 1 /* no borrow */ : 0 /* borrow */);
    set_z(m == 0);
    set_n((m & 0x80) ? 1 : 0);
}

void cpx() {
    unsigned char k = readM();
    unsigned char l = x;
    unsigned char m = l-k;
    set_c(l >= k ? 1 /* no borrow */ : 0 /* borrow */);
    set_z(m == 0);
    set_n((m & 0x80) ? 1 : 0);
}

void cpy() {
    unsigned char k = readM();
    unsigned char l = y;
    unsigned char m = l-k;
    set_c(l >= k ? 1 /* no borrow */ : 0 /* borrow */);
    set_z(m == 0);
    set_n((m & 0x80) ? 1 : 0);
}

/* decrement */

void dec() {
    unsigned char res = readM()-1;
    writeM(res);
    set_z(res == 0);
    set_n((res & 0x80) ? 1 : 0);
}

void dex() {
    x--;
    set_z(x == 0);
    set_n((x & 0x80) ? 1 : 0);
}

void dey() {
    y--;
    set_z(y == 0);
    set_n((y & 0x80) ? 1 : 0);
}

/* exclusive OR */

void eor() {
    a = a ^ readM();
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
}

/* increment */

void inc() {
    unsigned char res = readM()+1;
    writeM(res);
    set_z(res == 0);
    set_n((res & 0x80) ? 1 : 0);
}

void inx() {
    x++;
    set_z(x == 0);
    set_n((x & 0x80) ? 1 : 0);
}

void iny() {
    y++;
    set_z(y == 0);
    set_n((y & 0x80) ? 1 : 0);
}

/* jumping */

void jmp() {
    pcl = abl;
    pch = abh;
}

void jsr() {
    unsigned char al = abl;
    unsigned char ah = abh;

    unsigned short addr = (pch << 8) + pcl - 1;

    /* push higher byte */
    abl = s;
    abh = 1;
    mwrite(addr>>8);
    s--;

    /* push lower byte */
    abl = s;
    abh = 1;
    mwrite(addr&0xFF);
    s--;

    /* update pch & pcl: */
    pcl = al;
    pch = ah;
}

/* loading */

void lda() {
    a = readM();
    set_z(a == 0);
    set_n((a & 0x80)?1:0);
}

void ldx() {
    x = readM();
    set_z(x == 0);
    set_n((x & 0x80)?1:0);
}

void ldy() {
    y = readM();
    set_z(y == 0);
    set_n((y & 0x80)?1:0);
}

void lsr() {
    unsigned char tmp = readM();
    set_c(tmp & 0x01);
    tmp = tmp >> 1;
    writeM(tmp);
    set_z(tmp == 0);
    set_n((tmp & 0x80) ? 1 : 0);
}

/* no operation */

void nop() {
}

/* or */

void ora() {
    a |= readM();
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
}

/* push and pop */

void pha() {
    /* push a */
    abl = s;
    abh = 1;
    mwrite(a);
    s--;
}

void php() {
    /* push p */
    abl = s;
    abh = 1;
    mwrite(p);
    s--;
}

void pla() {
    /* pop a */
    s++;
    abl = s;
    abh = 1;
    a = mread();
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
}

void plp() {
    /* pop p */
    s++;
    abl = s;
    abh = 1;
    p = mread();
}

/* rotation */

void rol() {
    unsigned char tmp = readM();
    unsigned char tc = get_c();
    set_c((tmp & 0x80)>>7);
    tmp = (tmp << 1) | tc;
    writeM(tmp);
    set_z(tmp == 0);
    set_n((tmp & 0x80) ? 1 : 0);
}

void ror() {
    unsigned char tmp = readM();
    unsigned char tc = get_c();
    set_c(tmp & 0x01);
    tmp = (tmp >> 1) | (tc << 7);
    writeM(tmp);
    set_z(tmp == 0);
    set_n((tmp & 0x80) ? 1 : 0);
}

void rti() {

    /* pop p */
    s++;
    abl = s;
    abh = 1;
    p = mread() & 0xEF; /* get p but without B */

    /* pop pcl */
    s++;
    abl = s;
    abh = 1;
    pcl = mread();

    /* pop pch */
    s++;
    abl = s;
    abh = 1;
    pch = mread();

}

void rts() {

    unsigned char low;
    unsigned char high;
    unsigned short addr;

    /* pop lower byte */
    s++;
    abl = s;
    abh = 1;
    low = mread();

    /* pop higher byte */
    s++;
    abl = s;
    abh = 1;
    high = mread();

    /* calculate address */
    addr = (high<<8) + low + 1;
    pcl = addr & 0xFF;
    pch = addr >> 8;

}

/* subtraction, set flags, store regs */

void sbc() {
    unsigned char k = readM() + (!get_c());
    unsigned short res = a - k;
    set_c(a >= k ? 1 /* no borrow */ : 0 /* borrow */);
    a = res;
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
    if (((signed short) res) < -128 || ((signed short) res) > 127)
        set_v(1);
    else
        set_v(0);
}

void sec() {
    set_c(1);
}

void sed() {
    set_d(1);
}

void sei() {
    set_i(1);
}

void sta() {
   writeM(a);
}

void stx() {
   writeM(x);
}

void sty() {
   writeM(y);
}

/* transfer */

void tax() {
    x = a;
    set_z(x == 0);
    set_n((x & 0x80) ? 1 : 0);
}

void tay() {
    y = a;
    set_z(y == 0);
    set_n((y & 0x80) ? 1 : 0);
}

void tsx() {
    x = s;
    set_z(x == 0);
    set_n((x & 0x80) ? 1 : 0);
}

void txa() {
    a = x;
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
}

void txs() {
    s = x;
}

void tya() {
    a = y;
    set_z(a == 0);
    set_n((a & 0x80) ? 1 : 0);
}

instr_t isa[] = {

{"adc",adc,0x69,0x6D,0x65,0xFF,0xFF,0x61,0x71,0x75,0x7D,0x79,0xFF,0xFF,0xFF,1},
{"and",and,0x29,0x2D,0x25,0xFF,0xFF,0x21,0x31,0x35,0x3D,0x39,0xFF,0xFF,0xFF,1},
{"asl",asl,0xFF,0x0E,0x06,0x0A,0xFF,0xFF,0xFF,0x16,0x1E,0xFF,0xFF,0xFF,0xFF,3},

{"bcc",bcc,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x90,0xFF,0xFF,0},
{"bcs",bcs,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xB0,0xFF,0xFF,0},
{"beq",beq,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xF0,0xFF,0xFF,0},
{"bit",bit,0xFF,0x2C,0x24,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,1},
{"bmi",bmi,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x30,0xFF,0xFF,0},
{"bne",bne,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xD0,0xFF,0xFF,0},
{"bpl",bpl,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x10,0xFF,0xFF,0},
{"brk",brk,0xFF,0xFF,0xFF,0xFF,0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"bvc",bvc,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x50,0xFF,0xFF,0},
{"bvs",bvs,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x70,0xFF,0xFF,0},

{"clc",clc,0xFF,0xFF,0xFF,0xFF,0x18,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"cld",cld,0xFF,0xFF,0xFF,0xFF,0xD8,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"cli",cli,0xFF,0xFF,0xFF,0xFF,0x58,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"clv",clv,0xFF,0xFF,0xFF,0xFF,0xB8,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"cmp",cmp,0xC9,0xCD,0xC5,0xFF,0xFF,0xC1,0xD1,0xD5,0xDD,0xD9,0xFF,0xFF,0xFF,1},
{"cpx",cpx,0xE0,0xEC,0xE4,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,1},
{"cpy",cpy,0xC0,0xCC,0xC4,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,1},

{"dec",dec,0xFF,0xCE,0xC6,0xFF,0xFF,0xFF,0xFF,0xD6,0xDE,0xFF,0xFF,0xFF,0xFF,3},
{"dex",dex,0xFF,0xFF,0xFF,0xFF,0xCA,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"dey",dey,0xFF,0xFF,0xFF,0xFF,0x88,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},

{"eor",eor,0x49,0x4D,0x45,0xFF,0xFF,0x41,0x51,0x55,0x5D,0x59,0xFF,0xFF,0xFF,1},

{"inc",inc,0xFF,0xEE,0xE6,0xFF,0xFF,0xFF,0xFF,0xF6,0xFE,0xFF,0xFF,0xFF,0xFF,3},
{"inx",inx,0xFF,0xFF,0xFF,0xFF,0xE8,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"iny",iny,0xFF,0xFF,0xFF,0xFF,0xC8,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},

{"jmp",jmp,0xFF,0x4C,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x6C,0xFF,0},
{"jsr",jsr,0xFF,0x20,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},

{"lda",lda,0xA9,0xAD,0xA5,0xFF,0xFF,0xA1,0xB1,0xB5,0xBD,0xB9,0xFF,0xFF,0xFF,1},
{"ldx",ldx,0xA2,0xAE,0xA6,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xBE,0xFF,0xFF,0xB6,1},
{"ldy",ldy,0xA0,0xAC,0xA4,0xFF,0xFF,0xFF,0xFF,0xB4,0xBC,0xFF,0xFF,0xFF,0xFF,1},
{"lsr",lsr,0xFF,0x4E,0x46,0x4A,0xFF,0xFF,0xFF,0x56,0x5E,0xFF,0xFF,0xFF,0xFF,3},

{"nop",nop,0xFF,0xFF,0xFF,0xFF,0xEA,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},

{"ora",ora,0x09,0x0D,0x05,0xFF,0xFF,0x01,0x11,0x15,0x1D,0x19,0xFF,0xFF,0xFF,1},

{"pha",pha,0xFF,0xFF,0xFF,0xFF,0x48,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"php",php,0xFF,0xFF,0xFF,0xFF,0x08,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"pla",pla,0xFF,0xFF,0xFF,0xFF,0x68,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"plp",plp,0xFF,0xFF,0xFF,0xFF,0x28,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},

{"rol",rol,0xFF,0x2E,0x26,0x2A,0xFF,0xFF,0xFF,0x36,0x3E,0xFF,0xFF,0xFF,0xFF,3},
{"ror",ror,0xFF,0x6E,0x66,0x6A,0xFF,0xFF,0xFF,0x76,0x7E,0xFF,0xFF,0xFF,0xFF,3},
{"rti",rti,0xFF,0xFF,0xFF,0xFF,0x40,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"rts",rts,0xFF,0xFF,0xFF,0xFF,0x60,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},

{"sbc",sbc,0xE9,0xED,0xE5,0xFF,0xFF,0xE1,0xF1,0xF5,0xFD,0xF9,0xFF,0xFF,0xFF,1},
{"sec",sec,0xFF,0xFF,0xFF,0xFF,0x38,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"sed",sed,0xFF,0xFF,0xFF,0xFF,0xF8,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"sei",sei,0xFF,0xFF,0xFF,0xFF,0x78,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"sta",sta,0xFF,0x8D,0x85,0xFF,0xFF,0x81,0x91,0x95,0x9D,0x99,0xFF,0xFF,0xFF,2},
{"stx",stx,0xFF,0x8E,0x86,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x96,2},
{"sty",sty,0xFF,0x8C,0x84,0xFF,0xFF,0xFF,0xFF,0x94,0xFF,0xFF,0xFF,0xFF,0xFF,2},

{"tax",tax,0xFF,0xFF,0xFF,0xFF,0xAA,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"tay",tay,0xFF,0xFF,0xFF,0xFF,0xA8,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"tsx",tsx,0xFF,0xFF,0xFF,0xFF,0xBA,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"txa",txa,0xFF,0xFF,0xFF,0xFF,0x8A,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"txs",txs,0xFF,0xFF,0xFF,0xFF,0x9A,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0},
{"tya",tya,0xFF,0xFF,0xFF,0xFF,0x98,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0}

};

/*****************************************************************************/
/*                              MACHINE CYCLE                                */
/*****************************************************************************/

void fetch() {

    abl = pcl;
    abh = pch;
    ir = mread();
    pcl += 1;
    pch += (pcl == 0);

}

void decode() {

    unsigned char tmp1, tmp2;
    unsigned short tmp, eff;
    extern int tick;

    /* invalid opcode? */
    if (opcodes[ir].instr == NULL) {
        fprintf(stderr,"Error: Invalid opcode! $%02X%02X:%02X\n",pch,pcl,ir);
        exit(-4);
    }

    /* determine the instruction handler */
    seq = opcodes[ir].instr->func;

    /* ouput the instruction */
    tmp = (pch<<8) | pcl;
    if (!testing) {
        tmp1 = cpu_mem_read(tmp+0);
        tmp2 = cpu_mem_read(tmp+1);
    } else {
        tmp1 = test_mem[tmp+0];
        tmp2 = test_mem[tmp+1];
    }

    /* load effective address */
    calc_eff_address();
    eff = abl | (abh << 8);

    /* print information */
    if (!printing)
        return;

    printf("$%04X: %s  ", tmp-1, opcodes[ir].instr->mnemonic);
    switch (opcodes[ir].mode) {

        case IMMEDIATE:
            printf("#$%02X", tmp1);
            break;

        case ABSOLUTE:
            printf("$%02X%02X", tmp2, tmp1);
            break;

        case ZEROPAGE:
            printf("$%02X\t", tmp1);
            break;

        case ACCUM:
            printf("\t");
            break;

        case IMPLIED:
            printf("\t");
            break;

        case INDX_INDIR:
            printf("($%02X,X)", tmp1);
            break;

        case INDIR_INDX:
            printf("($%02X),Y", tmp1);
            break;

        case INDX_ZERO_X:
            printf("$%02X,X", tmp1);
            break;

        case INDX_ABS_X:
            printf("$%02X%02X,X", tmp2, tmp1);
            break;

        case INDX_ABS_Y:
            printf("$%02X%02X,Y", tmp2, tmp1);
            break;

        case RELATIVE:
            printf("$%04X", (tmp+1)+((signed char) tmp1));
            break;

        case ABS_INDIR:
            printf("($%02X%02X)", tmp2, tmp1);
            break;

        case INDX_ZERO_Y:
            printf("$%02X,Y", tmp1);
            break;

        default:
            break;

    }

    printf("\t; eff=$%04X", eff);


}

void execute() {

    extern int tick;

    seq();

    if (!printing)
        return;

    printf(" a=$%02X x=$%02X y=$%02X s=$%02X p=$%02X\n", a, x, y, s, p);

}

void interrupt() {

    if (nmi_pulse) {
        /* NMI */
        nmi_pulse = 0;
        if (printing) {
            printf("\n\n\n\n\n\nNMI!!!\n\n\n\n");
        }

        /* push pch */
        abl = s;
        abh = 1;
        mwrite(pch);
        s--;

        /* push pcl */
        abl = s;
        abh = 1;
        mwrite(pcl);
        s--;

        /* push p */
        abl = s;
        abh = 1;
        mwrite(p);
        s--;

        /* set interrupt flag */
        set_i(1);

        /* load PC with the interupt handler */
        abl = 0xFA;
        abh = 0xFF;
        pcl = dbb = mread();
        abl = 0xFB;
        pch = dbb = mread();
    } else if (irq_pulse && (!get_i())) {
        /* IRQ */
        irq_pulse = 0;
        if (printing) {
            printf("\n\n\n\n\n\nIRQ!!!\n\n\n\n");
        }

        /* push pch */
        abl = s;
        abh = 1;
        mwrite(pch);
        s--;

        /* push pcl */
        abl = s;
        abh = 1;
        mwrite(pcl);
        s--;

        /* push p */
        abl = s;
        abh = 1;
        mwrite(p);
        s--;

        /* set interrupt flag */
        set_i(1);

        /* load PC with the interupt handler */
        abl = 0xFE;
        abh = 0xFF;
        pcl = dbb = mread();
        abl = 0xFF;
        pch = dbb = mread();
    }
}

void cpu_cycle() {

    fetch();
    decode();
    execute();
    interrupt();

}

void reset() {

    abl = 0xFC;
    abh = 0xFF;
    pcl = dbb = mread();
    abl = 0xFD;
    pch = dbb = mread();

}

void cpu_init() {

    int i, j;

    /* initialize opcode list */
    for (i = 0; i < sizeof(isa)/sizeof(instr_t); i++) {
        for (j = 0; j < 13; j++) {
            unsigned char opcode = isa[i].opcodes[j];
            if (opcode != 0xFF) {
                opcodes[opcode].instr = &isa[i];
                opcodes[opcode].mode  = j;
            }
        }
    }

    /* print modes for all opcodes */
/*    for (i = 0; i <= 0xFF; i++) {
        if (!(i%0x10)) {
            printf("\n");
            printf("-- row 0x%02X", i/0x10);
            printf("\n");
        }

        if (opcodes[i].instr) {
            printf("x\"%02X\"", opcodes[i].mode);
        } else {
            printf("x\"FF\"");
        }
        if ((i+1)%0x08) {
            printf(", ");
        } else {
            printf(",\n");
        }

    }*/

    /* print memory rules for all opcodes */
/*    for (i = 0; i <= 0xFF; i++) {
        if (!(i%0x10)) {
            printf("\n");
            printf("-- row 0x%02X", i/0x10);
            printf("\n");
        }

        if (opcodes[i].instr) {
            printf("\"%d%d\"", !!(opcodes[i].instr->mem&2),
                               !!(opcodes[i].instr->mem&1));
        } else {
            printf("\"00\"");
        }
        if ((i+1)%0x08) {
            printf(", ");
        } else {
            printf(",\n");
        }

    }*/

    /* opcode names */
    /*for (i = 0; i < sizeof(isa)/sizeof(instr_t); i++) {
        printf("constant I_");
        printf("%c", isa[i].mnemonic[0]-0x20);
        printf("%c", isa[i].mnemonic[1]-0x20);
        printf("%c", isa[i].mnemonic[2]-0x20);
        printf(" : STD_LOGIC_VECTOR (7 downto 0) : ");
        printf("x\"%02X\";\n", i);
    }*/

    /* mapping between opcodes and instructions */
/*    for (i = 0; i <= 0xFF; i++) {

        if (!(i%0x10)) {
            printf("\n");
            printf("-- row 0x%02X", i/0x10);
            printf("\n");
        }

        if (opcodes[i].instr) {
            printf("x\"%02X\"", opcodes[i].instr-isa);
        } else {
            printf("x\"FF\"");
        }
        if ((i+1)%0x08) {
            printf(", ");
        } else {
            printf(",\n");
        }

    }*/

    /* do the reset */
    reset();

}

void cpu_test() {

    int i;

    FILE *tf = fopen("test.bin", "r");
    FILE *of = fopen("test.out", "w");

    fread(test_mem, 0x10000, 1, tf);
    testing = 1;

    reset();
    s = 0xFF;
    p = 0x20;

    for (i = 0; i < 5000 && !test_hlt; i++)
        cpu_cycle();

    fwrite(test_mem, 0x10000, 1, of);

    fclose(tf);
    fclose(of);

    exit(0);

}

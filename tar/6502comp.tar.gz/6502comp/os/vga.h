#ifndef _6502COMP_VGA_H
#define _6502COMP_VGA_H

#define HEADER_ATTR     0x0E
#define FOOTER_ATTR     0x0F

extern char attr;
extern char fmt_attr;
extern char scan_attr;

void clear_screen(char attr);
void print_char(char c, char attr);
void print_int(int num, char attr);
void print_hex(int num, char attr);
void print_str(char *str, char attr);
void print_hf(int line, char *str, char attr);
void print_fmt(char *fmt, ...);

#endif

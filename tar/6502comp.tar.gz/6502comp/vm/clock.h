#ifndef VM_CLOCK_H
#define VM_CLOCK_H

int watch_events();
void clock_handler();

#endif

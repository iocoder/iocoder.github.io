#include <stdio.h>
#include <SDL/SDL.h>
#include <gtk/gtk.h>

#include "clock.h"
#include "ppu.h"

SDL_Surface* screen = NULL;

int main(int argc, char *argv[]) {

    int err;
    pthread_t ct[10];
    int args = 0;

    /* check the arguments */
    if (argc != 2) {
        fprintf(stderr,"Usage: %s [nes-file]\n",argv[0]?argv[0]:"nesparser");
        return -1;
    }

    /* print splash */
    printf("*********************************\n");
    printf("*  NESSIM - NES SIMULATOR v1.0  *\n");
    printf("*********************************\n");
    printf("\n");

    /* loading... */
    printf("The simulator is loading...\n");

    /* load the cartridge */
    if (err = cart_load(argv[1]))
        return err;

    /* initialize the clock */
    clock_init();

    /* initialize PPU */
    ppu_init();

    /* initialize CPU */
    cpu_init();

    /* initialize APU */
    apu_init();

    /* initialize SDL */
    SDL_Init(SDL_INIT_EVERYTHING);

    /* Set up screen */
    screen = SDL_SetVideoMode(256*3, 240*3, 32, SDL_SWSURFACE);

    /* the clock */
    clock_handler();

    /* quit SDL */
    SDL_Quit();

    /* done */
    return 0;

}

#ifndef _6502COMP_CALC_H
#define _6502COMP_CALC_H

void calc();

#endif

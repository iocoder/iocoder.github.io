/* Microasm Main File */

#include <stdio.h>
#include "microasm.h"

int main(int argc, char *argv[]) {

    /* streams: */
    FILE *rtl_file, *rom_file;

    /* return value: */
    int ret;

    /* make sure argument count is valid */
    if (argc != 3) {
        fprintf(stderr, "USAGE: %s rtl_file rom_file\n", argv[0]);
        return -1;
    }

    /* open RTL file: */
    if(!(rtl_file = fopen(argv[1], "r"))) {
        fprintf(stderr, "Can't open %s for read!\n", argv[1]);
        return -2;
    };

    /* open rom file: */
    if(!(rom_file = fopen(argv[2], "w"))) {
        fprintf(stderr, "Can't open %s for write!\n", argv[2]);
        return -2;
    };

    /* translate the RTL file: */
    ret = translate(rtl_file, rom_file);

    /* close all streams */
    fclose(rom_file);
    fclose(rtl_file);

    /* done */
    return ret;

}

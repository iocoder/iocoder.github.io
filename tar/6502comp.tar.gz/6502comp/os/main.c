#include "vga.h"
#include "kbd.h"
#include "shell.h"

void splash() {
    print_hf(0, "6502 FPGA Computer - 2014", HEADER_ATTR);
    print_hf(1, "Computer and Systems Engineering Department", HEADER_ATTR);
    print_hf(2, "Faculty of Engineering, Alexandria University",HEADER_ATTR);
    print_hf(28, "Designed by Mostafa Abd El-Aziz - 2014",FOOTER_ATTR);
    print_hf(29, "Contact me at iocoder@aol.com", FOOTER_ATTR);
}

void stats() {
    int i;
    print_fmt("\n");
    print_fmt("System Statistics:\n");
    print_fmt("-------------------\n");
    print_fmt("CPU Frequency: 50Mhz (20ns per micro-instruction)\n");
    print_fmt("RAM: 16KB ($0000-$3FFF)\n");
    print_fmt("VGA:  8KB ($6000-$7FFF)\n");
    print_fmt("ROM: 32KB ($8000-$FFFF)\n");
    for (i = 0; i < 80; i++)
        print_fmt("-");
}

int main() {
    clear_screen(attr);
    splash();
    stats();
    shell();
    return 0;
}

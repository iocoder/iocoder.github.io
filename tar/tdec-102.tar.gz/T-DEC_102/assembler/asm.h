#ifndef __ASM_H
#define __ASM_H

#include <string.h>

#include "linkedlist.h"

#define MAX_LINE_SIZE 4096
#define STRCPY(STR)   strcpy(malloc(strlen(STR)+1), STR)

typedef struct file {
    char *name;
    char *mode;
    FILE *fd;
    int cur_line;
} file_t;

typedef struct symbol {
    char *symname;
    int  address;
} symbol_t;

typedef struct instruct {
    linkedlist tokens;
    int i_op;
    file_t *file;
    int line;
    int size;
    int *bytes;
} instruct_t;

typedef struct job {
    file_t *files;
    linkedlist instructs;
    linkedlist symbols;
    int fcount;
    int binsize;
    char **regs;
    char **isa;
} job_t;

/* fiorics architecture */
extern char *regs[];
extern char *isa[];

/* prototype: */
int open_file(file_t *file, char *name, char *mode);
int reopen_file(file_t *file);
void close_file(file_t *file);
void strsplit(char *str, char *del, linkedlist *ret);
int get_line(file_t *asm_file, linkedlist *line);

int do_pass1(job_t *job);
#endif

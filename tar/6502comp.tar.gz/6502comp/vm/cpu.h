#ifndef VM_CPU_H
#define VM_CPU_H

void cpu_clk();
void cpu_init(char *microcode_name, char *lookup_name);

#endif


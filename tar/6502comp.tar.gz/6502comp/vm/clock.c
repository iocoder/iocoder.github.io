/* clock handler */

#include <SDL/SDL.h>
#include <sys/times.h>
#include <stdio.h>
#include <stdlib.h>

#include "clock.h"
#include "cpu.h"
#include "kbd.h"
#include "vga.h"

int watch_events() {
    /* handle events */
    SDL_Event e;
    while (SDL_PollEvent(&e) != 0) {
        if (e.type == SDL_QUIT) {
            vga_stop();
            return 1;
        } else if (e.type == SDL_KEYDOWN) {
            keydown(e);
        } else if (e.type == SDL_KEYUP) {
            keyup(e);
        }
    }
    return 0;
}

void clock_handler() {
    extern SDL_Surface* screen;
    int i;
    while(1) {
        for (i = 0; i < 200000; i++)
            cpu_clk();
        if (watch_events())
            return;
        kbd_clk();
    }
}

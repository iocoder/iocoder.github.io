#include <stdio.h>
#include <stdlib.h>

#include "mem.h"
#include "cpu.h"

/* interesting as hell! */

int nmi_pulse = 0; /* NMI */
int irq_pulse = 0; /* IRQ */

unsigned char test_mem[0x10000];
unsigned char testing  = 0;
unsigned char test_hlt = 0;

/*****************************************************************************/
/*                               REGISTERS                                   */
/*****************************************************************************/

static unsigned char PCL = 0;
static unsigned char PCH = 0;
static unsigned char A   = 0;
static unsigned char X   = 0;
static unsigned char Y   = 0;
static unsigned char S   = 0;
static unsigned char P   = 0;
static unsigned char T   = 0;
static unsigned char U   = 0;
static unsigned char AXL = 0;
static unsigned char AXH = 0;
static unsigned char AY  = 0;
static unsigned char AOL = 0;
static unsigned char AOH = 0;
static unsigned char AZL = 0;
static unsigned char AZH = 0;
static unsigned char AC  = 0;
static unsigned char AZ  = 0;
static unsigned char AN  = 0;
static unsigned char AV  = 0;
static unsigned char IC  = 0;
static unsigned char REP = 0;
static unsigned char IR  = 0;
static unsigned char ABL = 0;
static unsigned char ABH = 0;
static unsigned char _00 = 0x00;
static unsigned char _01 = 0x01;
static unsigned char _02 = 0x02;
static unsigned char _04 = 0x04;
static unsigned char _08 = 0x08;
static unsigned char _10 = 0x10;
static unsigned char _20 = 0x20;
static unsigned char _40 = 0x40;
static unsigned char _80 = 0x80;
static unsigned char _FA = 0xFA;
static unsigned char _FB = 0xFB;
static unsigned char _FC = 0xFC;
static unsigned char _FD = 0xFD;
static unsigned char _FE = 0xFE;
static unsigned char _FF = 0xFF;

void set_c(unsigned char val) {
    P = (P & (~0x01)) | (val?0x01:0);
}

void set_z(unsigned char val) {
    P = (P & (~0x02)) | (val?0x02:0);
}

void set_i(unsigned char val) {
    P = (P & (~0x04)) | (val?0x04:0);
}

void set_d(unsigned char val) {
    P = (P & (~0x08)) | (val?0x08:0);
}

void set_b(unsigned char val) {
    P = (P & (~0x10)) | (val?0x10:0);
}

void set_v(unsigned char val) {
    P = (P & (~0x40)) | (val?0x40:0);
}

void set_n(unsigned char val) {
    P = (P & (~0x80)) | (val?0x80:0);
}

int get_c() {
    return (P & 0x01) ? 1 : 0;
}

int get_z() {
    return (P & 0x02) ? 1 : 0;
}

int get_i() {
    return (P & 0x04) ? 1 : 0;
}

int get_d() {
    return (P & 0x08) ? 1 : 0;
}

int get_b() {
    return (P & 0x10) ? 1 : 0;
}

int get_v() {
    return (P & 0x40) ? 1 : 0;
}

int get_n() {
    return (P & 0x80) ? 1 : 0;
}

/*****************************************************************************/
/*                                ALU                                        */
/*****************************************************************************/

void alu_clk() {

    unsigned short AOP = (AOH<<8) | AOL;
    unsigned short AX  = (AXH<<8) | AXL;
    unsigned short AZZ;

    switch (AOP) {
        case 0x01: /* ADD */
            AZZ = AX + AY + (IC&1);
            if (REP && (AY&0x80))
                AZZ += 0xFF00;
            AZL = (AZZ>>0) & 0xFF;
            AZH = (AZZ>>8) & 0xFF;
            AC  = (AZH != 0); /* 0: no carry, 1: carry */
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            if (((signed short) AZZ) < -128 || ((signed short) AZZ) > 127)
                AV = 1;
            else
                AV = 0;
            break;

        case 0x02: /* SUB */
            AZZ = AX - AY - (!(IC&1));
            AZL = (AZZ>>0) & 0xFF;
            AZH = (AZZ>>8) & 0xFF; /* plz don't forget this */
            AC  = (AZH == 0); /* 0: borrow, 1: no borrow */
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            if (((signed short) AZZ) < -128 || ((signed short) AZZ) > 127)
                AV = 1;
            else
                AV = 0;
            break;

        case 0x04: /* SHL */
            AZL = (AXL << 1) | (IC&1);
            AC  = !!(AXL & 0x80);
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            AV  = 0;
            break;

        case 0x08: /* SHR */
            AZL = (AXL >> 1) | ((IC&1) << 7);
            AC  = AXL & 0x01;
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            AV  = 0;
            break;

        case 0x10: /* BIT */
            AZL = AXL & AY;
            AC  = 0;
            AZ  = (AZL == 0);
            AN  = !!(AXL & 0x80);
            AV  = !!(AXL & 0x40);
            break;

        case 0x20: /* AND */
            AZL = AXL & AY;
            AC  = 0;
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            AV  = 0;
            break;

        case 0x40: /* OR */
            AZL = AXL | AY;
            AC  = 0;
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            AV  = 0;
            break;

        case 0x80: /* EOR */
            AZL = AXL ^ AY;
            AC  = 0;
            AZ  = (AZL == 0);
            AN  = !!(AZL & 0x80);
            AV  = 0;
            break;

        default:
            break;
    }

}

/*****************************************************************************/
/*                            CONTROL UNIT                                   */
/*****************************************************************************/

unsigned short microcode[2048]; /* microprogram */
unsigned short lookup[256];     /* lookup table */
unsigned short SEQ = 0;         /* sequencer */
unsigned char SRC  = 0;
unsigned char DEST = 0;

void cu_clk() {
    int bit0    = (microcode[SEQ]>>0) & 1;
    int bit1    = (microcode[SEQ]>>1) & 1;
    int bit234  = (microcode[SEQ]>>2) & 7;
    int bit5_15 = (microcode[SEQ]>>5) & 2047;
    int m       = 0;
    if (bit1) {
        switch(bit234) {
            case 0:
                m = 1;
                break;

            case 1:
                m = get_c();
                break;

            case 2:
                m = get_z();
                break;

            case 3:
                m = get_n();
                break;

            case 4:
                m = get_v();
                break;

            case 5:
                m = nmi_pulse;
                break;

            case 6:
                m = irq_pulse & (!get_i());
                break;

            case 7:
                m = 0;
                break;

            default:
                m = 0;
                break;
        }

    }

    /* update sequencer */
    if (bit1 == 0 && bit0 == 1) {
        SEQ = lookup[IR] + ((microcode[SEQ]>>2)&7);
    } else if (bit1 == 1 && bit0 == m) {
        if (SEQ == bit5_15 && bit234 == 0) {
            /* Infinite Goto */
            printf("BRK happened!\n");
            test_hlt = 1;
        }
        SEQ = bit5_15;
    } else {
        SEQ = SEQ + 1;
    }

    /*printf("SEQ: %d\n", SEQ);*/

    /* now read from the memory */
    if ((microcode[SEQ] & 3) == 0) {
        SRC  = (microcode[SEQ]>>2) & 31;
        DEST = (microcode[SEQ]>>7) & 31;
    } else {
        SRC = DEST = 0;
    }

    /*printf("PC: $%02X%02X\n", PCH, PCL);*/

}

/*****************************************************************************/
/*                          MEMORY INTERFACE                                 */
/*****************************************************************************/

int last_state_is_mem = 0;
unsigned char last_read = 0;

unsigned char mread() {
    if (last_state_is_mem)
        return last_read;
    if (testing)
        last_read = test_mem[(ABH<<8) | ABL];
    else
        last_read = mem_read((ABH<<8) | ABL);
    last_state_is_mem = 1;
    /*printf("MEMR of $%02X at: $%02X%02X\n", last_read, ABH, ABL);*/
    return last_read;
}

void mwrite(unsigned char val) {
    if (last_state_is_mem)
        return;
    if (testing)
        test_mem[(ABH<<8) | ABL] = val;
    else
        mem_write((ABH<<8) | ABL, val);
    last_read = val;
    last_state_is_mem = 1;
    /*printf("MEMW of $%02X at: $%02X%02X\n", val, ABH, ABL);*/
}

/*****************************************************************************/
/*                           CPU CLOCK CYCLE                                 */
/*****************************************************************************/

void cpu_clk() {

    unsigned char IMM = 0;

    alu_clk();
    cu_clk();

    switch (SRC) {
        case 0:
            break;

        case 1:
            IMM = mread();
            break;

        case 2:
            IMM = PCL;
            break;

        case 3:
            IMM = PCH;
            break;

        case 4:
            IMM = A;
            break;

        case 5:
            IMM = X;
            break;

        case 6:
            IMM = Y;
            break;

        case 7:
            IMM = S;
            break;

        case 8:
            IMM = P;
            break;

        case 9:
            IMM = T;
            break;

        case 10:
            IMM = U;
            break;

        case 11:
            IMM = AC;
            break;

        case 12:
            IMM = AZ;
            break;

        case 13:
            IMM = AN;
            break;

        case 14:
            IMM = AV;
            break;

        case 15:
            IMM = AZL;
            break;

        case 16:
            IMM = AZH;
            break;

        case 17:
            IMM = _00;
            break;

        case 18:
            IMM = _01;
            break;

        case 19:
            IMM = _02;
            break;

        case 20:
            IMM = _04;
            break;

        case 21:
            IMM = _08;
            break;

        case 22:
            IMM = _10;
            break;

        case 23:
            IMM = _20;
            break;

        case 24:
            IMM = _40;
            break;

        case 25:
            IMM = _80;
            break;

        case 26:
            IMM = _FA;
            break;

        case 27:
            IMM = _FB;
            break;

        case 28:
            IMM = _FC;
            break;

        case 29:
            IMM = _FD;
            break;

        case 30:
            IMM = _FE;
            break;

        case 31:
            IMM = _FF;
            break;

        default:
            break;
    }

    switch (DEST) {
        case 0:
            break;

        case 1:
            mwrite(IMM);
            break;

        case 2:
            PCL = IMM;
            break;

        case 3:
            PCH = IMM;
            break;

        case 4:
            A = IMM;
            break;

        case 5:
            X = IMM;
            break;

        case 6:
            Y = IMM;
            break;

        case 7:
            S = IMM;
            break;

        case 8:
            P = IMM;
            break;

        case 9:
            T = IMM;
            break;

        case 10:
            U = IMM;
            break;

        case 11:
            set_c(IMM);
            break;

        case 12:
            set_z(IMM);
            break;

        case 13:
            set_n(IMM);
            break;

        case 14:
            set_v(IMM);
            break;

        case 15:
            AXL = IMM;
            break;

        case 16:
            AXH = IMM;
            break;

        case 17:
            AY = IMM;
            break;

        case 18:
            AOL = IMM;
            break;

        case 19:
            IR = IMM;
            break;

        case 20:
            ABL = IMM;
            break;

        case 21:
            ABH = IMM;
            break;

        case 22:
            AOH = IMM;
            break;

        case 23:
            if (IMM)
                irq_pulse = 0;
            break;

        case 24:
            if (IMM)
                nmi_pulse = 0;
            break;

        case 25:
            IC = IMM;
            break;

        case 26:
            REP = IMM;
            break;

        case 27:
            set_i(IMM);
            break;

        case 28:
            set_d(IMM);
            break;

        case 29:
            break;

        case 30:
            break;

        case 31:
            break;

        default:
            break;
    }

    if (SRC != 1 && DEST != 1)
        last_state_is_mem = 0;

}

void cpu_test() {

    int i;
    FILE *tf, *of;

    if (!(tf = fopen("test.bin", "r"))) {
        fprintf(stderr, "Cannot open test.bin!\n");
        exit(-1);
    }

    of = fopen("test.out", "w");

    fread(test_mem, 0x10000, 1, tf);
    testing = 1;

    for (i = 0; i < 5000 && !test_hlt; i++)
        cpu_clk();

    if (!test_hlt)
        printf("Didn't halt yet!\n");
    else
        printf("Clocks: %d\n", i);

    printf("PC: $%02X%02X, A: $%02X, ", PCH, PCL, A);
    printf("P: $%02X\n", P);

    fwrite(test_mem, 0x10000, 1, of);

    fclose(tf);
    fclose(of);

    exit(0);

}

void cpu_init(char *microcode_name, char *lookup_name) {

    FILE *f;

    /* read microcode rom */
    if (!(f = fopen(microcode_name, "r"))) {
        fprintf(stderr, "Error: cannot open %s.\n", microcode_name);
        exit(-2);
    }
    fread(microcode, sizeof(microcode), 1, f);
    fclose(f);

    /* read lookup table */
    if (!(f = fopen(lookup_name, "r"))) {
        fprintf(stderr, "Error: cannot open %s.\n", lookup_name);
        exit(-2);
    }
    fread(lookup, sizeof(lookup), 1, f);
    fclose(f);

    /* testing? */
    if (testing)
        cpu_test();

}

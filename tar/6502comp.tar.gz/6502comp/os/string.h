#ifndef _6502COMP_STRING_H
#define _6502COMP_STRING_H

int str_len(char *str);
int str_cmp(const char *str1, const char *str2);
int str_to_int(char *str, int *num);

#endif

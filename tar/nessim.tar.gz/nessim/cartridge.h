#ifndef NESSIM_CARTRIDGE_H
#define NESSIM_CARTRIDGE_H

unsigned char cart_cpu_read(unsigned short addr);
void cart_cpu_write(unsigned short addr, unsigned char data);
unsigned char cart_ppu_read(unsigned short addr);
void cart_ppu_write(unsigned short addr, unsigned char data);
int cart_load(char *nesfname);

#endif

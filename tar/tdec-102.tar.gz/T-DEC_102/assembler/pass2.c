/* second pass */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "linkedlist.h"
#include "asm.h"

int get_op(job_t *job, instruct_t *instruct, int op) {
    int i = 0, j = 0;
    char **code = &job->isa[instruct->i_op];

    /* loop */
    while(*code) {
        if ((!strcmp(*code, "NUM")) || (!strcmp(*code, "REG"))) {
            i++;
            if (i == op)
                break;
        }
        j++;
        code++;
    }

    /* done */
    return j;
}

int solveref(job_t *job, char *symname) {

    int i;
    symbol_t *sym;
    for (i = 0; i < linkedlist_size(&(job->symbols)); i++) {
        sym = linkedlist_get(&(job->symbols), i);
        if (!strcmp(sym->symname, symname))
            return sym->address;
    }
    return -1;

}

int get_machine_code(job_t *job, instruct_t *instruct) {

    char **code = &job->isa[instruct->i_op];

    int curbit = 0;
    int curbyte = 0;

    int num;
    int psize;

    int id;
    char *val, *type;
    char mod;

    /* seek the criteria part */
    while(*code)
        code++;
    code++;

    /* now translate */
    /* printf("instruction:\n"); */
    while(*code) {

        if ((*code)[0] == 'O' && (*code)[1] == 'P') {
            /* Operand token */

            /* read operand */
            id = get_op(job, instruct, (*code)[2]-'0');
            val = linkedlist_get(&(instruct->tokens), id);
            type = job->isa[instruct->i_op+id];

            /* convert data into numbers */
            if (!strcmp(type, "REG")) {
                /* register */
                for (num = 0; job->regs[num]; num++)
                    if (!strcmp(job->regs[num], val))
                        break;
            } else {
                /* number/reference */
                if (val[0] == '^' || val[0] == '~') {
                    mod = val[0];
                    val++;
                } else {
                    mod = 0;
                }

                if (!strcmp(type, "NUM") && val[0]>='0'&& val[0]<='9') {
                    /* write number */
                    num = strtol(val, NULL, 0);
                } else {
                    /* reference */
                    if ((num = solveref(job, val)) == -1) {
                        fprintf(stderr, "Error: Invalid reference (%s:%d).\n",
                                        instruct->file->name,
                                        instruct->line);
                        return -2;

                    }
                }

                if (mod == '^') {
                    /* upper half */
                    num = (num&0xFF00)>>8;
                } else if (mod == '~') {
                    /* lower byte */
                    num &= 0xFF;
                }
            }

            /* size of this part */
            psize = atoi(&((*code)[4]));

        } else {

            /* age is just a number */
            num = 0;
            id = 0;
            while((*code)[id] != ':')
                num = (num<<1) | ((*code)[id++]-'0');
            psize = atoi(&((*code)[id+1]));

        }

        if (num >= (1<<psize)) {
                fprintf(stderr, "Error: Overflow (%s:%d).\n",
                                instruct->file->name,
                                instruct->line);
                return -2;
        }

        /* write the numeric value to the instruction code */
        /* printf("token: %d %d\n", num, psize); */
        while (psize--) {
            instruct->bytes[curbyte] |= (num & 1) << curbit;
            curbit++;
            if (curbit == 8) {
                curbit = 0;
                curbyte++;
            }
            num >>= 1;
        }

        code++;
    }
    return 0;

}

int do_pass2(job_t *job) {
    /* convert instructions into machine code */
    int i;
    for (i = 0; i < linkedlist_size(&(job->instructs)); i++) {
        if (get_machine_code(job, linkedlist_get(&(job->instructs), i))) {
            return -2;
        }
    }
    return 0;
}
